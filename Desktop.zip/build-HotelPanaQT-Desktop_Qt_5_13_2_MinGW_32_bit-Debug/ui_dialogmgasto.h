/********************************************************************************
** Form generated from reading UI file 'dialogmgasto.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGMGASTO_H
#define UI_DIALOGMGASTO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_DialogMgasto
{
public:
    QDialogButtonBox *buttonBox;
    QLabel *label;
    QLabel *label_4;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_3;
    QLabel *label_9;
    QLabel *label_3;
    QPushButton *pushButton;
    QLabel *label_2;
    QLabel *label_5;
    QLineEdit *lineEdit_2;
    QLabel *label_7;
    QLabel *label_11;
    QLineEdit *lineEdit_4;
    QLineEdit *lineEdit_5;
    QLineEdit *lineEdit_6;
    QLineEdit *lineEdit_7;
    QFrame *line;

    void setupUi(QDialog *DialogMgasto)
    {
        if (DialogMgasto->objectName().isEmpty())
            DialogMgasto->setObjectName(QString::fromUtf8("DialogMgasto"));
        DialogMgasto->resize(439, 344);
        QFont font;
        font.setFamily(QString::fromUtf8("Arial"));
        font.setPointSize(12);
        DialogMgasto->setFont(font);
        buttonBox = new QDialogButtonBox(DialogMgasto);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(130, 300, 161, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        label = new QLabel(DialogMgasto);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(90, 10, 251, 31));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Arial"));
        font1.setPointSize(24);
        font1.setBold(true);
        font1.setWeight(75);
        label->setFont(font1);
        label_4 = new QLabel(DialogMgasto);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(19, 183, 71, 16));
        lineEdit = new QLineEdit(DialogMgasto);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(99, 121, 41, 21));
        lineEdit_3 = new QLineEdit(DialogMgasto);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(89, 180, 41, 20));
        label_9 = new QLabel(DialogMgasto);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(19, 273, 51, 16));
        label_3 = new QLabel(DialogMgasto);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(19, 153, 101, 16));
        pushButton = new QPushButton(DialogMgasto);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(90, 54, 75, 23));
        label_2 = new QLabel(DialogMgasto);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(19, 123, 81, 16));
        label_5 = new QLabel(DialogMgasto);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(19, 213, 91, 16));
        lineEdit_2 = new QLineEdit(DialogMgasto);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(123, 150, 41, 20));
        label_7 = new QLabel(DialogMgasto);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(19, 243, 91, 16));
        label_11 = new QLabel(DialogMgasto);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(20, 60, 47, 13));
        lineEdit_4 = new QLineEdit(DialogMgasto);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(42, 56, 41, 21));
        lineEdit_5 = new QLineEdit(DialogMgasto);
        lineEdit_5->setObjectName(QString::fromUtf8("lineEdit_5"));
        lineEdit_5->setGeometry(QRect(109, 210, 291, 20));
        lineEdit_6 = new QLineEdit(DialogMgasto);
        lineEdit_6->setObjectName(QString::fromUtf8("lineEdit_6"));
        lineEdit_6->setGeometry(QRect(80, 240, 41, 20));
        lineEdit_7 = new QLineEdit(DialogMgasto);
        lineEdit_7->setObjectName(QString::fromUtf8("lineEdit_7"));
        lineEdit_7->setGeometry(QRect(70, 270, 41, 20));
        line = new QFrame(DialogMgasto);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(20, 100, 401, 16));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        retranslateUi(DialogMgasto);
        QObject::connect(buttonBox, SIGNAL(accepted()), DialogMgasto, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), DialogMgasto, SLOT(reject()));

        QMetaObject::connectSlotsByName(DialogMgasto);
    } // setupUi

    void retranslateUi(QDialog *DialogMgasto)
    {
        DialogMgasto->setWindowTitle(QCoreApplication::translate("DialogMgasto", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("DialogMgasto", "Modificar Gasto", nullptr));
        label_4->setText(QCoreApplication::translate("DialogMgasto", "Cantidad:", nullptr));
        lineEdit->setText(QString());
        lineEdit_3->setText(QString());
        label_9->setText(QCoreApplication::translate("DialogMgasto", "Total: $", nullptr));
        label_3->setText(QCoreApplication::translate("DialogMgasto", "Cod Producto:", nullptr));
        pushButton->setText(QCoreApplication::translate("DialogMgasto", "Consulta", nullptr));
        label_2->setText(QCoreApplication::translate("DialogMgasto", "Habitacion:", nullptr));
        label_5->setText(QCoreApplication::translate("DialogMgasto", "Descripcion:", nullptr));
        lineEdit_2->setText(QString());
        label_7->setText(QCoreApplication::translate("DialogMgasto", "Costo: $", nullptr));
        label_11->setText(QCoreApplication::translate("DialogMgasto", "ID:", nullptr));
        lineEdit_4->setText(QString());
        lineEdit_5->setText(QString());
        lineEdit_6->setText(QString());
        lineEdit_7->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class DialogMgasto: public Ui_DialogMgasto {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGMGASTO_H
