/********************************************************************************
** Form generated from reading UI file 'dialogcfgasto.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGCFGASTO_H
#define UI_DIALOGCFGASTO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>

QT_BEGIN_NAMESPACE

class Ui_DialogCFgasto
{
public:
    QLineEdit *lineEdit;
    QPushButton *pushButton_2;
    QLabel *label;
    QLabel *label_2;
    QTableWidget *tableWidget;
    QPushButton *pushButton;
    QLabel *label_3;
    QDateEdit *dateEdit;
    QLabel *label_4;
    QDateEdit *dateEdit_2;

    void setupUi(QDialog *DialogCFgasto)
    {
        if (DialogCFgasto->objectName().isEmpty())
            DialogCFgasto->setObjectName(QString::fromUtf8("DialogCFgasto"));
        DialogCFgasto->resize(663, 307);
        lineEdit = new QLineEdit(DialogCFgasto);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(93, 53, 51, 20));
        pushButton_2 = new QPushButton(DialogCFgasto);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(280, 270, 75, 23));
        QFont font;
        font.setFamily(QString::fromUtf8("Arial"));
        font.setPointSize(12);
        pushButton_2->setFont(font);
        label = new QLabel(DialogCFgasto);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(130, 10, 351, 31));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Arial"));
        font1.setPointSize(24);
        font1.setBold(true);
        font1.setWeight(75);
        label->setFont(font1);
        label_2 = new QLabel(DialogCFgasto);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(14, 56, 81, 16));
        label_2->setFont(font);
        tableWidget = new QTableWidget(DialogCFgasto);
        if (tableWidget->columnCount() < 6)
            tableWidget->setColumnCount(6);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(5, __qtablewidgetitem5);
        if (tableWidget->rowCount() < 4)
            tableWidget->setRowCount(4);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(0, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(1, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(2, __qtablewidgetitem8);
        QTableWidgetItem *__qtablewidgetitem9 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(3, __qtablewidgetitem9);
        QTableWidgetItem *__qtablewidgetitem10 = new QTableWidgetItem();
        tableWidget->setItem(0, 0, __qtablewidgetitem10);
        QTableWidgetItem *__qtablewidgetitem11 = new QTableWidgetItem();
        tableWidget->setItem(0, 1, __qtablewidgetitem11);
        QTableWidgetItem *__qtablewidgetitem12 = new QTableWidgetItem();
        tableWidget->setItem(0, 2, __qtablewidgetitem12);
        QTableWidgetItem *__qtablewidgetitem13 = new QTableWidgetItem();
        tableWidget->setItem(0, 3, __qtablewidgetitem13);
        QTableWidgetItem *__qtablewidgetitem14 = new QTableWidgetItem();
        tableWidget->setItem(0, 4, __qtablewidgetitem14);
        QTableWidgetItem *__qtablewidgetitem15 = new QTableWidgetItem();
        tableWidget->setItem(0, 5, __qtablewidgetitem15);
        QTableWidgetItem *__qtablewidgetitem16 = new QTableWidgetItem();
        tableWidget->setItem(1, 0, __qtablewidgetitem16);
        QTableWidgetItem *__qtablewidgetitem17 = new QTableWidgetItem();
        tableWidget->setItem(1, 1, __qtablewidgetitem17);
        QTableWidgetItem *__qtablewidgetitem18 = new QTableWidgetItem();
        tableWidget->setItem(1, 2, __qtablewidgetitem18);
        QTableWidgetItem *__qtablewidgetitem19 = new QTableWidgetItem();
        tableWidget->setItem(1, 3, __qtablewidgetitem19);
        QTableWidgetItem *__qtablewidgetitem20 = new QTableWidgetItem();
        tableWidget->setItem(1, 4, __qtablewidgetitem20);
        QTableWidgetItem *__qtablewidgetitem21 = new QTableWidgetItem();
        tableWidget->setItem(1, 5, __qtablewidgetitem21);
        QTableWidgetItem *__qtablewidgetitem22 = new QTableWidgetItem();
        tableWidget->setItem(2, 0, __qtablewidgetitem22);
        QTableWidgetItem *__qtablewidgetitem23 = new QTableWidgetItem();
        tableWidget->setItem(2, 1, __qtablewidgetitem23);
        QTableWidgetItem *__qtablewidgetitem24 = new QTableWidgetItem();
        tableWidget->setItem(2, 2, __qtablewidgetitem24);
        QTableWidgetItem *__qtablewidgetitem25 = new QTableWidgetItem();
        tableWidget->setItem(2, 3, __qtablewidgetitem25);
        QTableWidgetItem *__qtablewidgetitem26 = new QTableWidgetItem();
        tableWidget->setItem(2, 4, __qtablewidgetitem26);
        QTableWidgetItem *__qtablewidgetitem27 = new QTableWidgetItem();
        tableWidget->setItem(2, 5, __qtablewidgetitem27);
        QTableWidgetItem *__qtablewidgetitem28 = new QTableWidgetItem();
        tableWidget->setItem(3, 0, __qtablewidgetitem28);
        QTableWidgetItem *__qtablewidgetitem29 = new QTableWidgetItem();
        tableWidget->setItem(3, 1, __qtablewidgetitem29);
        QTableWidgetItem *__qtablewidgetitem30 = new QTableWidgetItem();
        tableWidget->setItem(3, 2, __qtablewidgetitem30);
        QTableWidgetItem *__qtablewidgetitem31 = new QTableWidgetItem();
        tableWidget->setItem(3, 3, __qtablewidgetitem31);
        QTableWidgetItem *__qtablewidgetitem32 = new QTableWidgetItem();
        tableWidget->setItem(3, 4, __qtablewidgetitem32);
        QTableWidgetItem *__qtablewidgetitem33 = new QTableWidgetItem();
        tableWidget->setItem(3, 5, __qtablewidgetitem33);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setGeometry(QRect(10, 110, 621, 151));
        pushButton = new QPushButton(DialogCFgasto);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(330, 77, 75, 23));
        pushButton->setFont(font);
        label_3 = new QLabel(DialogCFgasto);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(16, 80, 41, 16));
        label_3->setFont(font);
        dateEdit = new QDateEdit(DialogCFgasto);
        dateEdit->setObjectName(QString::fromUtf8("dateEdit"));
        dateEdit->setGeometry(QRect(60, 76, 110, 22));
        label_4 = new QLabel(DialogCFgasto);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(176, 80, 41, 16));
        label_4->setFont(font);
        dateEdit_2 = new QDateEdit(DialogCFgasto);
        dateEdit_2->setObjectName(QString::fromUtf8("dateEdit_2"));
        dateEdit_2->setGeometry(QRect(212, 76, 110, 22));

        retranslateUi(DialogCFgasto);

        QMetaObject::connectSlotsByName(DialogCFgasto);
    } // setupUi

    void retranslateUi(QDialog *DialogCFgasto)
    {
        DialogCFgasto->setWindowTitle(QCoreApplication::translate("DialogCFgasto", "Dialog", nullptr));
        lineEdit->setText(QString());
        pushButton_2->setText(QCoreApplication::translate("DialogCFgasto", "ok", nullptr));
        label->setText(QCoreApplication::translate("DialogCFgasto", "Consultar Gasto Fecha", nullptr));
        label_2->setText(QCoreApplication::translate("DialogCFgasto", "Habitacion:", nullptr));
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("DialogCFgasto", "ID", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("DialogCFgasto", "Cod Producto", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QCoreApplication::translate("DialogCFgasto", "Costo", nullptr));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QCoreApplication::translate("DialogCFgasto", "Cantidad", nullptr));
        QTableWidgetItem *___qtablewidgetitem4 = tableWidget->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QCoreApplication::translate("DialogCFgasto", "Descripcion", nullptr));
        QTableWidgetItem *___qtablewidgetitem5 = tableWidget->horizontalHeaderItem(5);
        ___qtablewidgetitem5->setText(QCoreApplication::translate("DialogCFgasto", "Total", nullptr));
        QTableWidgetItem *___qtablewidgetitem6 = tableWidget->verticalHeaderItem(0);
        ___qtablewidgetitem6->setText(QCoreApplication::translate("DialogCFgasto", "1", nullptr));
        QTableWidgetItem *___qtablewidgetitem7 = tableWidget->verticalHeaderItem(1);
        ___qtablewidgetitem7->setText(QCoreApplication::translate("DialogCFgasto", "2", nullptr));
        QTableWidgetItem *___qtablewidgetitem8 = tableWidget->verticalHeaderItem(2);
        ___qtablewidgetitem8->setText(QCoreApplication::translate("DialogCFgasto", "3", nullptr));
        QTableWidgetItem *___qtablewidgetitem9 = tableWidget->verticalHeaderItem(3);
        ___qtablewidgetitem9->setText(QCoreApplication::translate("DialogCFgasto", "4", nullptr));

        const bool __sortingEnabled = tableWidget->isSortingEnabled();
        tableWidget->setSortingEnabled(false);
        QTableWidgetItem *___qtablewidgetitem10 = tableWidget->item(0, 0);
        ___qtablewidgetitem10->setText(QCoreApplication::translate("DialogCFgasto", "55", nullptr));
        QTableWidgetItem *___qtablewidgetitem11 = tableWidget->item(0, 1);
        ___qtablewidgetitem11->setText(QCoreApplication::translate("DialogCFgasto", "665", nullptr));
        QTableWidgetItem *___qtablewidgetitem12 = tableWidget->item(0, 2);
        ___qtablewidgetitem12->setText(QCoreApplication::translate("DialogCFgasto", "100", nullptr));
        QTableWidgetItem *___qtablewidgetitem13 = tableWidget->item(0, 3);
        ___qtablewidgetitem13->setText(QCoreApplication::translate("DialogCFgasto", "1", nullptr));
        QTableWidgetItem *___qtablewidgetitem14 = tableWidget->item(0, 4);
        ___qtablewidgetitem14->setText(QCoreApplication::translate("DialogCFgasto", "Coca Cola 2.5L", nullptr));
        QTableWidgetItem *___qtablewidgetitem15 = tableWidget->item(0, 5);
        ___qtablewidgetitem15->setText(QCoreApplication::translate("DialogCFgasto", "100", nullptr));
        QTableWidgetItem *___qtablewidgetitem16 = tableWidget->item(1, 0);
        ___qtablewidgetitem16->setText(QCoreApplication::translate("DialogCFgasto", "65", nullptr));
        QTableWidgetItem *___qtablewidgetitem17 = tableWidget->item(1, 1);
        ___qtablewidgetitem17->setText(QCoreApplication::translate("DialogCFgasto", "121", nullptr));
        QTableWidgetItem *___qtablewidgetitem18 = tableWidget->item(1, 2);
        ___qtablewidgetitem18->setText(QCoreApplication::translate("DialogCFgasto", "56", nullptr));
        QTableWidgetItem *___qtablewidgetitem19 = tableWidget->item(1, 3);
        ___qtablewidgetitem19->setText(QCoreApplication::translate("DialogCFgasto", "6", nullptr));
        QTableWidgetItem *___qtablewidgetitem20 = tableWidget->item(1, 4);
        ___qtablewidgetitem20->setText(QCoreApplication::translate("DialogCFgasto", "Cafe Mediano", nullptr));
        QTableWidgetItem *___qtablewidgetitem21 = tableWidget->item(1, 5);
        ___qtablewidgetitem21->setText(QCoreApplication::translate("DialogCFgasto", "336", nullptr));
        QTableWidgetItem *___qtablewidgetitem22 = tableWidget->item(2, 0);
        ___qtablewidgetitem22->setText(QCoreApplication::translate("DialogCFgasto", "72", nullptr));
        QTableWidgetItem *___qtablewidgetitem23 = tableWidget->item(2, 1);
        ___qtablewidgetitem23->setText(QCoreApplication::translate("DialogCFgasto", "335", nullptr));
        QTableWidgetItem *___qtablewidgetitem24 = tableWidget->item(2, 2);
        ___qtablewidgetitem24->setText(QCoreApplication::translate("DialogCFgasto", "70", nullptr));
        QTableWidgetItem *___qtablewidgetitem25 = tableWidget->item(2, 3);
        ___qtablewidgetitem25->setText(QCoreApplication::translate("DialogCFgasto", "2", nullptr));
        QTableWidgetItem *___qtablewidgetitem26 = tableWidget->item(2, 4);
        ___qtablewidgetitem26->setText(QCoreApplication::translate("DialogCFgasto", "Tosta JYQ", nullptr));
        QTableWidgetItem *___qtablewidgetitem27 = tableWidget->item(2, 5);
        ___qtablewidgetitem27->setText(QCoreApplication::translate("DialogCFgasto", "140", nullptr));
        QTableWidgetItem *___qtablewidgetitem28 = tableWidget->item(3, 0);
        ___qtablewidgetitem28->setText(QCoreApplication::translate("DialogCFgasto", "78", nullptr));
        QTableWidgetItem *___qtablewidgetitem29 = tableWidget->item(3, 1);
        ___qtablewidgetitem29->setText(QCoreApplication::translate("DialogCFgasto", "22", nullptr));
        QTableWidgetItem *___qtablewidgetitem30 = tableWidget->item(3, 2);
        ___qtablewidgetitem30->setText(QCoreApplication::translate("DialogCFgasto", "15", nullptr));
        QTableWidgetItem *___qtablewidgetitem31 = tableWidget->item(3, 3);
        ___qtablewidgetitem31->setText(QCoreApplication::translate("DialogCFgasto", "1", nullptr));
        QTableWidgetItem *___qtablewidgetitem32 = tableWidget->item(3, 4);
        ___qtablewidgetitem32->setText(QCoreApplication::translate("DialogCFgasto", "Adicional Crema", nullptr));
        QTableWidgetItem *___qtablewidgetitem33 = tableWidget->item(3, 5);
        ___qtablewidgetitem33->setText(QCoreApplication::translate("DialogCFgasto", "15", nullptr));
        tableWidget->setSortingEnabled(__sortingEnabled);

        pushButton->setText(QCoreApplication::translate("DialogCFgasto", "Consulta", nullptr));
        label_3->setText(QCoreApplication::translate("DialogCFgasto", "Inicio:", nullptr));
        label_4->setText(QCoreApplication::translate("DialogCFgasto", "final:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DialogCFgasto: public Ui_DialogCFgasto {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGCFGASTO_H
