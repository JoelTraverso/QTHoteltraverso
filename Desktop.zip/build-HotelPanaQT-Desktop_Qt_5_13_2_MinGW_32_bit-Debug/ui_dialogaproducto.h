/********************************************************************************
** Form generated from reading UI file 'dialogaproducto.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGAPRODUCTO_H
#define UI_DIALOGAPRODUCTO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_DialogAproducto
{
public:
    QDialogButtonBox *buttonBox;
    QLabel *label;
    QLineEdit *lineEdit;
    QLabel *label_5;
    QLabel *label_2;
    QLabel *label_4;
    QLabel *label_7;
    QLabel *label_11;
    QLabel *label_3;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_8;
    QPushButton *pushButton_2;

    void setupUi(QDialog *DialogAproducto)
    {
        if (DialogAproducto->objectName().isEmpty())
            DialogAproducto->setObjectName(QString::fromUtf8("DialogAproducto"));
        DialogAproducto->resize(400, 270);
        QFont font;
        font.setFamily(QString::fromUtf8("Arial"));
        font.setPointSize(12);
        DialogAproducto->setFont(font);
        buttonBox = new QDialogButtonBox(DialogAproducto);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(110, 230, 161, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        label = new QLabel(DialogAproducto);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(70, 10, 261, 41));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Arial"));
        font1.setPointSize(24);
        font1.setBold(true);
        font1.setWeight(75);
        label->setFont(font1);
        lineEdit = new QLineEdit(DialogAproducto);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(42, 72, 51, 20));
        label_5 = new QLabel(DialogAproducto);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(22, 193, 47, 13));
        label_2 = new QLabel(DialogAproducto);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(22, 103, 61, 16));
        label_4 = new QLabel(DialogAproducto);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(22, 163, 71, 16));
        label_7 = new QLabel(DialogAproducto);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(85, 102, 161, 16));
        label_11 = new QLabel(DialogAproducto);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(22, 74, 21, 16));
        label_3 = new QLabel(DialogAproducto);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(22, 133, 91, 16));
        label_9 = new QLabel(DialogAproducto);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(88, 164, 47, 13));
        label_10 = new QLabel(DialogAproducto);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(70, 194, 47, 13));
        label_8 = new QLabel(DialogAproducto);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(114, 133, 161, 16));
        pushButton_2 = new QPushButton(DialogAproducto);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(100, 70, 75, 23));

        retranslateUi(DialogAproducto);
        QObject::connect(buttonBox, SIGNAL(accepted()), DialogAproducto, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), DialogAproducto, SLOT(reject()));

        QMetaObject::connectSlotsByName(DialogAproducto);
    } // setupUi

    void retranslateUi(QDialog *DialogAproducto)
    {
        DialogAproducto->setWindowTitle(QCoreApplication::translate("DialogAproducto", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("DialogAproducto", "Anular Producto", nullptr));
        label_5->setText(QCoreApplication::translate("DialogAproducto", "Stock:", nullptr));
        label_2->setText(QCoreApplication::translate("DialogAproducto", "Nombre:", nullptr));
        label_4->setText(QCoreApplication::translate("DialogAproducto", "Precio: $", nullptr));
        label_7->setText(QCoreApplication::translate("DialogAproducto", "Vino Trapiche 980cm3", nullptr));
        label_11->setText(QCoreApplication::translate("DialogAproducto", "ID:", nullptr));
        label_3->setText(QCoreApplication::translate("DialogAproducto", "Descripcion:", nullptr));
        label_9->setText(QCoreApplication::translate("DialogAproducto", "560", nullptr));
        label_10->setText(QCoreApplication::translate("DialogAproducto", "80", nullptr));
        label_8->setText(QCoreApplication::translate("DialogAproducto", "Vino Malbec Mendoza", nullptr));
        pushButton_2->setText(QCoreApplication::translate("DialogAproducto", "Consulta", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DialogAproducto: public Ui_DialogAproducto {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGAPRODUCTO_H
