/********************************************************************************
** Form generated from reading UI file 'dialogcstock.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGCSTOCK_H
#define UI_DIALOGCSTOCK_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_DialogCstock
{
public:
    QDialogButtonBox *buttonBox;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *lineEdit;
    QPushButton *pushButton;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLineEdit *lineEdit_2;

    void setupUi(QDialog *DialogCstock)
    {
        if (DialogCstock->objectName().isEmpty())
            DialogCstock->setObjectName(QString::fromUtf8("DialogCstock"));
        DialogCstock->resize(366, 246);
        QFont font;
        font.setFamily(QString::fromUtf8("Arial"));
        font.setPointSize(12);
        DialogCstock->setFont(font);
        buttonBox = new QDialogButtonBox(DialogCstock);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(90, 200, 161, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        label = new QLabel(DialogCstock);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(80, 0, 221, 41));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Arial"));
        font1.setPointSize(24);
        font1.setBold(true);
        font1.setWeight(75);
        label->setFont(font1);
        label_2 = new QLabel(DialogCstock);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(10, 60, 21, 16));
        lineEdit = new QLineEdit(DialogCstock);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(30, 58, 113, 20));
        pushButton = new QPushButton(DialogCstock);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(150, 57, 75, 23));
        label_3 = new QLabel(DialogCstock);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(10, 100, 61, 16));
        label_4 = new QLabel(DialogCstock);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(73, 101, 131, 16));
        label_5 = new QLabel(DialogCstock);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(10, 130, 121, 16));
        label_6 = new QLabel(DialogCstock);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(128, 131, 41, 16));
        label_7 = new QLabel(DialogCstock);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(10, 160, 71, 16));
        lineEdit_2 = new QLineEdit(DialogCstock);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(80, 158, 51, 20));

        retranslateUi(DialogCstock);
        QObject::connect(buttonBox, SIGNAL(accepted()), DialogCstock, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), DialogCstock, SLOT(reject()));

        QMetaObject::connectSlotsByName(DialogCstock);
    } // setupUi

    void retranslateUi(QDialog *DialogCstock)
    {
        DialogCstock->setWindowTitle(QCoreApplication::translate("DialogCstock", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("DialogCstock", "Agregar Stock", nullptr));
        label_2->setText(QCoreApplication::translate("DialogCstock", "ID:", nullptr));
        pushButton->setText(QCoreApplication::translate("DialogCstock", "Consulta", nullptr));
        label_3->setText(QCoreApplication::translate("DialogCstock", "Nombre:", nullptr));
        label_4->setText(QCoreApplication::translate("DialogCstock", "RedBull 374 cm3", nullptr));
        label_5->setText(QCoreApplication::translate("DialogCstock", "Cantidad Actual:", nullptr));
        label_6->setText(QCoreApplication::translate("DialogCstock", "30", nullptr));
        label_7->setText(QCoreApplication::translate("DialogCstock", "Cantidad:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DialogCstock: public Ui_DialogCstock {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGCSTOCK_H
