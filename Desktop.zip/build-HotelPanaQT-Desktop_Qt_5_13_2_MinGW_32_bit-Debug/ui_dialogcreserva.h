/********************************************************************************
** Form generated from reading UI file 'dialogcreserva.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGCRESERVA_H
#define UI_DIALOGCRESERVA_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_DialogCreserva
{
public:
    QDialogButtonBox *buttonBox;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *lineEdit;
    QPushButton *pushButton;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_13;
    QLabel *label_14;

    void setupUi(QDialog *DialogCreserva)
    {
        if (DialogCreserva->objectName().isEmpty())
            DialogCreserva->setObjectName(QString::fromUtf8("DialogCreserva"));
        DialogCreserva->resize(425, 343);
        QFont font;
        font.setFamily(QString::fromUtf8("Arial"));
        font.setPointSize(12);
        DialogCreserva->setFont(font);
        buttonBox = new QDialogButtonBox(DialogCreserva);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(-70, 300, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        label = new QLabel(DialogCreserva);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(60, 10, 281, 31));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Arial"));
        font1.setPointSize(24);
        font1.setBold(true);
        font1.setWeight(75);
        label->setFont(font1);
        label_2 = new QLabel(DialogCreserva);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(20, 60, 101, 16));
        lineEdit = new QLineEdit(DialogCreserva);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(120, 57, 81, 20));
        pushButton = new QPushButton(DialogCreserva);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(210, 56, 75, 23));
        label_3 = new QLabel(DialogCreserva);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(20, 90, 61, 16));
        label_4 = new QLabel(DialogCreserva);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(82, 90, 181, 16));
        label_5 = new QLabel(DialogCreserva);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(20, 120, 61, 16));
        label_6 = new QLabel(DialogCreserva);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(82, 120, 81, 16));
        label_7 = new QLabel(DialogCreserva);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(20, 150, 81, 16));
        label_8 = new QLabel(DialogCreserva);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(100, 150, 41, 16));
        label_9 = new QLabel(DialogCreserva);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(20, 180, 91, 16));
        label_10 = new QLabel(DialogCreserva);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(20, 210, 101, 16));
        label_11 = new QLabel(DialogCreserva);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(111, 180, 91, 16));
        label_12 = new QLabel(DialogCreserva);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(120, 210, 91, 16));
        label_13 = new QLabel(DialogCreserva);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(20, 240, 61, 21));
        label_14 = new QLabel(DialogCreserva);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(77, 243, 51, 16));

        retranslateUi(DialogCreserva);
        QObject::connect(buttonBox, SIGNAL(accepted()), DialogCreserva, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), DialogCreserva, SLOT(reject()));

        QMetaObject::connectSlotsByName(DialogCreserva);
    } // setupUi

    void retranslateUi(QDialog *DialogCreserva)
    {
        DialogCreserva->setWindowTitle(QCoreApplication::translate("DialogCreserva", "Cancelar Reserva", nullptr));
        label->setText(QCoreApplication::translate("DialogCreserva", "Cancelar Reserva", nullptr));
        label_2->setText(QCoreApplication::translate("DialogCreserva", "Cod Reserva:", nullptr));
        pushButton->setText(QCoreApplication::translate("DialogCreserva", "Consultar", nullptr));
        label_3->setText(QCoreApplication::translate("DialogCreserva", "Nombre:", nullptr));
        label_4->setText(QCoreApplication::translate("DialogCreserva", "Mauricio Rafael", nullptr));
        label_5->setText(QCoreApplication::translate("DialogCreserva", "Apellido:", nullptr));
        label_6->setText(QCoreApplication::translate("DialogCreserva", "Fernandez", nullptr));
        label_7->setText(QCoreApplication::translate("DialogCreserva", "Habitacion:", nullptr));
        label_8->setText(QCoreApplication::translate("DialogCreserva", "178", nullptr));
        label_9->setText(QCoreApplication::translate("DialogCreserva", "Fecha Inicio:", nullptr));
        label_10->setText(QCoreApplication::translate("DialogCreserva", "Fecha Salida:", nullptr));
        label_11->setText(QCoreApplication::translate("DialogCreserva", "22/12/2019", nullptr));
        label_12->setText(QCoreApplication::translate("DialogCreserva", "15/01/2020", nullptr));
        label_13->setText(QCoreApplication::translate("DialogCreserva", "Pago: $", nullptr));
        label_14->setText(QCoreApplication::translate("DialogCreserva", "2500", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DialogCreserva: public Ui_DialogCreserva {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGCRESERVA_H
