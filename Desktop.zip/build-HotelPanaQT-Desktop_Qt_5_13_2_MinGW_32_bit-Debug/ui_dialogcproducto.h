/********************************************************************************
** Form generated from reading UI file 'dialogcproducto.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGCPRODUCTO_H
#define UI_DIALOGCPRODUCTO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>

QT_BEGIN_NAMESPACE

class Ui_DialogCproducto
{
public:
    QDialogButtonBox *buttonBox;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_4;
    QCheckBox *checkBox;

    void setupUi(QDialog *DialogCproducto)
    {
        if (DialogCproducto->objectName().isEmpty())
            DialogCproducto->setObjectName(QString::fromUtf8("DialogCproducto"));
        DialogCproducto->resize(400, 295);
        QFont font;
        font.setFamily(QString::fromUtf8("Arial"));
        font.setPointSize(12);
        DialogCproducto->setFont(font);
        buttonBox = new QDialogButtonBox(DialogCproducto);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(95, 250, 171, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        label = new QLabel(DialogCproducto);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(65, 10, 251, 31));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Arial"));
        font1.setPointSize(24);
        font1.setBold(true);
        font1.setWeight(75);
        label->setFont(font1);
        label_2 = new QLabel(DialogCproducto);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(10, 70, 61, 16));
        label_3 = new QLabel(DialogCproducto);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(10, 100, 91, 16));
        label_4 = new QLabel(DialogCproducto);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(10, 130, 71, 16));
        label_5 = new QLabel(DialogCproducto);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(10, 160, 47, 13));
        label_6 = new QLabel(DialogCproducto);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(10, 190, 61, 16));
        lineEdit = new QLineEdit(DialogCproducto);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(72, 67, 113, 20));
        lineEdit_2 = new QLineEdit(DialogCproducto);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(101, 98, 271, 20));
        lineEdit_3 = new QLineEdit(DialogCproducto);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(76, 127, 51, 20));
        lineEdit_4 = new QLineEdit(DialogCproducto);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(60, 155, 51, 20));
        checkBox = new QCheckBox(DialogCproducto);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        checkBox->setGeometry(QRect(69, 190, 16, 20));

        retranslateUi(DialogCproducto);
        QObject::connect(buttonBox, SIGNAL(accepted()), DialogCproducto, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), DialogCproducto, SLOT(reject()));

        QMetaObject::connectSlotsByName(DialogCproducto);
    } // setupUi

    void retranslateUi(QDialog *DialogCproducto)
    {
        DialogCproducto->setWindowTitle(QCoreApplication::translate("DialogCproducto", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("DialogCproducto", "A\303\261adir Producto", nullptr));
        label_2->setText(QCoreApplication::translate("DialogCproducto", "Nombre:", nullptr));
        label_3->setText(QCoreApplication::translate("DialogCproducto", "Descripcion:", nullptr));
        label_4->setText(QCoreApplication::translate("DialogCproducto", "Precio: $", nullptr));
        label_5->setText(QCoreApplication::translate("DialogCproducto", "Stock:", nullptr));
        label_6->setText(QCoreApplication::translate("DialogCproducto", "Estado:", nullptr));
        checkBox->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class DialogCproducto: public Ui_DialogCproducto {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGCPRODUCTO_H
