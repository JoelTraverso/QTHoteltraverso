/********************************************************************************
** Form generated from reading UI file 'dialogreservanueva.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGRESERVANUEVA_H
#define UI_DIALOGRESERVANUEVA_H

#include <QtCore/QDate>
#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>

QT_BEGIN_NAMESPACE

class Ui_DialogReservaNueva
{
public:
    QDialogButtonBox *buttonBox;
    QLabel *label;
    QLineEdit *lineEdit;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_4;
    QComboBox *comboBox;
    QDateEdit *dateEdit;
    QDateEdit *dateEdit_2;
    QLabel *label_8;

    void setupUi(QDialog *DialogReservaNueva)
    {
        if (DialogReservaNueva->objectName().isEmpty())
            DialogReservaNueva->setObjectName(QString::fromUtf8("DialogReservaNueva"));
        DialogReservaNueva->resize(617, 336);
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(DialogReservaNueva->sizePolicy().hasHeightForWidth());
        DialogReservaNueva->setSizePolicy(sizePolicy);
        QFont font;
        font.setFamily(QString::fromUtf8("Arial"));
        font.setPointSize(12);
        DialogReservaNueva->setFont(font);
        buttonBox = new QDialogButtonBox(DialogReservaNueva);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(140, 290, 201, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        label = new QLabel(DialogReservaNueva);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 73, 31, 16));
        label->setFont(font);
        lineEdit = new QLineEdit(DialogReservaNueva);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(50, 69, 113, 20));
        label_2 = new QLabel(DialogReservaNueva);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(20, 103, 61, 16));
        label_2->setFont(font);
        label_3 = new QLabel(DialogReservaNueva);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(20, 133, 61, 16));
        label_3->setFont(font);
        label_4 = new QLabel(DialogReservaNueva);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(20, 163, 101, 16));
        label_4->setFont(font);
        label_5 = new QLabel(DialogReservaNueva);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(20, 193, 91, 16));
        label_5->setFont(font);
        label_6 = new QLabel(DialogReservaNueva);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(20, 223, 101, 16));
        label_6->setFont(font);
        label_7 = new QLabel(DialogReservaNueva);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(20, 250, 141, 21));
        label_7->setFont(font);
        lineEdit_2 = new QLineEdit(DialogReservaNueva);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(80, 100, 113, 20));
        lineEdit_3 = new QLineEdit(DialogReservaNueva);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(80, 130, 113, 20));
        lineEdit_4 = new QLineEdit(DialogReservaNueva);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(155, 250, 51, 20));
        comboBox = new QComboBox(DialogReservaNueva);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(127, 160, 151, 22));
        dateEdit = new QDateEdit(DialogReservaNueva);
        dateEdit->setObjectName(QString::fromUtf8("dateEdit"));
        dateEdit->setGeometry(QRect(120, 190, 110, 22));
        dateEdit->setMaximumDateTime(QDateTime(QDate(2021, 12, 31), QTime(23, 59, 59)));
        dateEdit->setMinimumDateTime(QDateTime(QDate(2019, 11, 2), QTime(0, 0, 0)));
        dateEdit->setCalendarPopup(true);
        dateEdit->setDate(QDate(2019, 11, 14));
        dateEdit_2 = new QDateEdit(DialogReservaNueva);
        dateEdit_2->setObjectName(QString::fromUtf8("dateEdit_2"));
        dateEdit_2->setGeometry(QRect(120, 220, 110, 22));
        dateEdit_2->setMaximumDateTime(QDateTime(QDate(2021, 12, 31), QTime(23, 59, 59)));
        dateEdit_2->setMinimumDateTime(QDateTime(QDate(2019, 11, 2), QTime(0, 0, 0)));
        dateEdit_2->setCalendarPopup(true);
        dateEdit_2->setDate(QDate(2019, 11, 16));
        label_8 = new QLabel(DialogReservaNueva);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(170, 10, 231, 41));
        QFont font1;
        font1.setPointSize(24);
        font1.setBold(true);
        font1.setWeight(75);
        label_8->setFont(font1);

        retranslateUi(DialogReservaNueva);
        QObject::connect(buttonBox, SIGNAL(accepted()), DialogReservaNueva, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), DialogReservaNueva, SLOT(reject()));

        QMetaObject::connectSlotsByName(DialogReservaNueva);
    } // setupUi

    void retranslateUi(QDialog *DialogReservaNueva)
    {
        DialogReservaNueva->setWindowTitle(QCoreApplication::translate("DialogReservaNueva", "Nueva Reserva", nullptr));
        label->setText(QCoreApplication::translate("DialogReservaNueva", "DNI", nullptr));
        label_2->setText(QCoreApplication::translate("DialogReservaNueva", "Nombre", nullptr));
        label_3->setText(QCoreApplication::translate("DialogReservaNueva", "Apellido", nullptr));
        label_4->setText(QCoreApplication::translate("DialogReservaNueva", "Tipo Habitaion", nullptr));
        label_5->setText(QCoreApplication::translate("DialogReservaNueva", "Fecha Inicio", nullptr));
        label_6->setText(QCoreApplication::translate("DialogReservaNueva", "Fecha Salida", nullptr));
        label_7->setText(QCoreApplication::translate("DialogReservaNueva", "Pago Adelantado $", nullptr));
        comboBox->setItemText(0, QCoreApplication::translate("DialogReservaNueva", "Suite Presidencial", nullptr));
        comboBox->setItemText(1, QCoreApplication::translate("DialogReservaNueva", "Master Suite", nullptr));
        comboBox->setItemText(2, QCoreApplication::translate("DialogReservaNueva", "Suite standar", nullptr));
        comboBox->setItemText(3, QCoreApplication::translate("DialogReservaNueva", "Regular", nullptr));

        label_8->setText(QCoreApplication::translate("DialogReservaNueva", "Nueva Reserva", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DialogReservaNueva: public Ui_DialogReservaNueva {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGRESERVANUEVA_H
