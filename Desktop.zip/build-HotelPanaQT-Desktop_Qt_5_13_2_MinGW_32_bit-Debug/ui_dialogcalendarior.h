/********************************************************************************
** Form generated from reading UI file 'dialogcalendarior.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGCALENDARIOR_H
#define UI_DIALOGCALENDARIOR_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCalendarWidget>
#include <QtWidgets/QDialog>

QT_BEGIN_NAMESPACE

class Ui_DialogCalendarioR
{
public:
    QCalendarWidget *calendarWidget;

    void setupUi(QDialog *DialogCalendarioR)
    {
        if (DialogCalendarioR->objectName().isEmpty())
            DialogCalendarioR->setObjectName(QString::fromUtf8("DialogCalendarioR"));
        DialogCalendarioR->resize(1021, 655);
        calendarWidget = new QCalendarWidget(DialogCalendarioR);
        calendarWidget->setObjectName(QString::fromUtf8("calendarWidget"));
        calendarWidget->setGeometry(QRect(1, 2, 1021, 651));
        calendarWidget->setVerticalHeaderFormat(QCalendarWidget::NoVerticalHeader);

        retranslateUi(DialogCalendarioR);

        QMetaObject::connectSlotsByName(DialogCalendarioR);
    } // setupUi

    void retranslateUi(QDialog *DialogCalendarioR)
    {
        DialogCalendarioR->setWindowTitle(QCoreApplication::translate("DialogCalendarioR", "Calendario Reservas", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DialogCalendarioR: public Ui_DialogCalendarioR {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGCALENDARIOR_H
