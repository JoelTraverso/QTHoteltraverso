/********************************************************************************
** Form generated from reading UI file 'dialogmoempleados.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGMOEMPLEADOS_H
#define UI_DIALOGMOEMPLEADOS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>

QT_BEGIN_NAMESPACE

class Ui_DialogMOempleados
{
public:
    QDialogButtonBox *buttonBox;
    QLabel *label_2;
    QCheckBox *checkBox_2;
    QRadioButton *radioButton_3;
    QLineEdit *lineEdit_9;
    QLabel *label_12;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label;
    QRadioButton *radioButton;
    QLabel *label_13;
    QLabel *label_4;
    QRadioButton *radioButton_2;
    QLineEdit *lineEdit_5;
    QLineEdit *lineEdit_6;
    QCheckBox *checkBox;
    QLineEdit *lineEdit_4;
    QLabel *label_11;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_7;
    QLabel *label_9;
    QLineEdit *lineEdit_8;
    QCheckBox *checkBox_3;
    QLineEdit *lineEdit_3;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_10;
    QComboBox *comboBox;
    QLabel *label_3;
    QLineEdit *lineEdit_2;
    QLabel *label_14;
    QLineEdit *lineEdit_10;
    QPushButton *pushButton;
    QFrame *line;

    void setupUi(QDialog *DialogMOempleados)
    {
        if (DialogMOempleados->objectName().isEmpty())
            DialogMOempleados->setObjectName(QString::fromUtf8("DialogMOempleados"));
        DialogMOempleados->resize(565, 545);
        QFont font;
        font.setFamily(QString::fromUtf8("Arial"));
        font.setPointSize(12);
        DialogMOempleados->setFont(font);
        buttonBox = new QDialogButtonBox(DialogMOempleados);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(240, 490, 161, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        label_2 = new QLabel(DialogMOempleados);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(26, 122, 61, 16));
        checkBox_2 = new QCheckBox(DialogMOempleados);
        checkBox_2->setObjectName(QString::fromUtf8("checkBox_2"));
        checkBox_2->setGeometry(QRect(156, 332, 70, 17));
        radioButton_3 = new QRadioButton(DialogMOempleados);
        radioButton_3->setObjectName(QString::fromUtf8("radioButton_3"));
        radioButton_3->setGeometry(QRect(246, 302, 82, 17));
        lineEdit_9 = new QLineEdit(DialogMOempleados);
        lineEdit_9->setObjectName(QString::fromUtf8("lineEdit_9"));
        lineEdit_9->setGeometry(QRect(85, 450, 113, 20));
        label_12 = new QLabel(DialogMOempleados);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(26, 422, 51, 16));
        label_7 = new QLabel(DialogMOempleados);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(26, 272, 61, 16));
        label_8 = new QLabel(DialogMOempleados);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(26, 302, 47, 13));
        label = new QLabel(DialogMOempleados);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(130, 0, 311, 41));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Arial"));
        font1.setPointSize(24);
        font1.setBold(true);
        font1.setWeight(75);
        label->setFont(font1);
        radioButton = new QRadioButton(DialogMOempleados);
        radioButton->setObjectName(QString::fromUtf8("radioButton"));
        radioButton->setGeometry(QRect(76, 302, 82, 17));
        label_13 = new QLabel(DialogMOempleados);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(26, 452, 61, 16));
        label_4 = new QLabel(DialogMOempleados);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(26, 182, 81, 16));
        radioButton_2 = new QRadioButton(DialogMOempleados);
        radioButton_2->setObjectName(QString::fromUtf8("radioButton_2"));
        radioButton_2->setGeometry(QRect(166, 302, 82, 17));
        lineEdit_5 = new QLineEdit(DialogMOempleados);
        lineEdit_5->setObjectName(QString::fromUtf8("lineEdit_5"));
        lineEdit_5->setGeometry(QRect(93, 239, 131, 20));
        lineEdit_6 = new QLineEdit(DialogMOempleados);
        lineEdit_6->setObjectName(QString::fromUtf8("lineEdit_6"));
        lineEdit_6->setGeometry(QRect(84, 269, 141, 20));
        checkBox = new QCheckBox(DialogMOempleados);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        checkBox->setGeometry(QRect(76, 332, 101, 17));
        lineEdit_4 = new QLineEdit(DialogMOempleados);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(57, 209, 81, 20));
        label_11 = new QLabel(DialogMOempleados);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(26, 392, 41, 16));
        lineEdit = new QLineEdit(DialogMOempleados);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(90, 119, 211, 20));
        lineEdit_7 = new QLineEdit(DialogMOempleados);
        lineEdit_7->setObjectName(QString::fromUtf8("lineEdit_7"));
        lineEdit_7->setGeometry(QRect(96, 360, 71, 20));
        label_9 = new QLabel(DialogMOempleados);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(26, 332, 47, 13));
        lineEdit_8 = new QLineEdit(DialogMOempleados);
        lineEdit_8->setObjectName(QString::fromUtf8("lineEdit_8"));
        lineEdit_8->setGeometry(QRect(64, 390, 113, 20));
        checkBox_3 = new QCheckBox(DialogMOempleados);
        checkBox_3->setObjectName(QString::fromUtf8("checkBox_3"));
        checkBox_3->setGeometry(QRect(226, 332, 70, 17));
        lineEdit_3 = new QLineEdit(DialogMOempleados);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(99, 180, 201, 20));
        label_5 = new QLabel(DialogMOempleados);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(26, 212, 31, 16));
        label_6 = new QLabel(DialogMOempleados);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(26, 242, 71, 16));
        label_10 = new QLabel(DialogMOempleados);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(26, 362, 71, 16));
        comboBox = new QComboBox(DialogMOempleados);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(81, 416, 140, 25));
        label_3 = new QLabel(DialogMOempleados);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(26, 152, 61, 16));
        lineEdit_2 = new QLineEdit(DialogMOempleados);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(90, 150, 211, 20));
        label_14 = new QLabel(DialogMOempleados);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(26, 60, 61, 21));
        lineEdit_10 = new QLineEdit(DialogMOempleados);
        lineEdit_10->setObjectName(QString::fromUtf8("lineEdit_10"));
        lineEdit_10->setGeometry(QRect(80, 60, 113, 20));
        pushButton = new QPushButton(DialogMOempleados);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(200, 58, 75, 23));
        line = new QFrame(DialogMOempleados);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(30, 90, 501, 20));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        retranslateUi(DialogMOempleados);
        QObject::connect(buttonBox, SIGNAL(accepted()), DialogMOempleados, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), DialogMOempleados, SLOT(reject()));

        QMetaObject::connectSlotsByName(DialogMOempleados);
    } // setupUi

    void retranslateUi(QDialog *DialogMOempleados)
    {
        DialogMOempleados->setWindowTitle(QCoreApplication::translate("DialogMOempleados", "Dialog", nullptr));
        label_2->setText(QCoreApplication::translate("DialogMOempleados", "Nombre:", nullptr));
        checkBox_2->setText(QCoreApplication::translate("DialogMOempleados", "Tarde", nullptr));
        radioButton_3->setText(QCoreApplication::translate("DialogMOempleados", "Otro", nullptr));
        label_12->setText(QCoreApplication::translate("DialogMOempleados", "Sector:", nullptr));
        label_7->setText(QCoreApplication::translate("DialogMOempleados", "Celular:", nullptr));
        label_8->setText(QCoreApplication::translate("DialogMOempleados", "Sexo:", nullptr));
        label->setText(QCoreApplication::translate("DialogMOempleados", "Modificar Empleado", nullptr));
        radioButton->setText(QCoreApplication::translate("DialogMOempleados", "Hombre", nullptr));
        label_13->setText(QCoreApplication::translate("DialogMOempleados", "Puesto:", nullptr));
        label_4->setText(QCoreApplication::translate("DialogMOempleados", "Direccion:", nullptr));
        radioButton_2->setText(QCoreApplication::translate("DialogMOempleados", "Mujer", nullptr));
        lineEdit_5->setText(QCoreApplication::translate("DialogMOempleados", "+54", nullptr));
        lineEdit_6->setText(QCoreApplication::translate("DialogMOempleados", "(011)", nullptr));
        checkBox->setText(QCoreApplication::translate("DialogMOempleados", "Ma\303\261ana", nullptr));
        lineEdit_4->setText(QString());
        label_11->setText(QCoreApplication::translate("DialogMOempleados", "Cuil:", nullptr));
        lineEdit_7->setText(QString());
        label_9->setText(QCoreApplication::translate("DialogMOempleados", "Turno:", nullptr));
        checkBox_3->setText(QCoreApplication::translate("DialogMOempleados", "Noche", nullptr));
        lineEdit_3->setText(QString());
        label_5->setText(QCoreApplication::translate("DialogMOempleados", "DNI:", nullptr));
        label_6->setText(QCoreApplication::translate("DialogMOempleados", "Telefono:", nullptr));
        label_10->setText(QCoreApplication::translate("DialogMOempleados", "Sueldo: $", nullptr));
        comboBox->setItemText(0, QCoreApplication::translate("DialogMOempleados", "Seguridad", nullptr));
        comboBox->setItemText(1, QCoreApplication::translate("DialogMOempleados", "Limpieza", nullptr));
        comboBox->setItemText(2, QCoreApplication::translate("DialogMOempleados", "Administrativo", nullptr));
        comboBox->setItemText(3, QCoreApplication::translate("DialogMOempleados", "Mantenimiento", nullptr));
        comboBox->setItemText(4, QCoreApplication::translate("DialogMOempleados", "Otro", nullptr));

        label_3->setText(QCoreApplication::translate("DialogMOempleados", "Apellido:", nullptr));
        lineEdit_2->setText(QString());
        label_14->setText(QCoreApplication::translate("DialogMOempleados", "Legajo:", nullptr));
        pushButton->setText(QCoreApplication::translate("DialogMOempleados", "Consulta", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DialogMOempleados: public Ui_DialogMOempleados {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGMOEMPLEADOS_H
