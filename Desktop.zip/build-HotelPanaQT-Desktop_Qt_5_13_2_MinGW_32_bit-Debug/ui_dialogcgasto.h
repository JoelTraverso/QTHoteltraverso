/********************************************************************************
** Form generated from reading UI file 'dialogcgasto.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGCGASTO_H
#define UI_DIALOGCGASTO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>

QT_BEGIN_NAMESPACE

class Ui_Dialogcgasto
{
public:
    QLabel *label;
    QPushButton *pushButton_2;
    QLabel *label_2;
    QLineEdit *lineEdit;
    QPushButton *pushButton;
    QTableWidget *tableWidget;

    void setupUi(QDialog *Dialogcgasto)
    {
        if (Dialogcgasto->objectName().isEmpty())
            Dialogcgasto->setObjectName(QString::fromUtf8("Dialogcgasto"));
        Dialogcgasto->resize(672, 300);
        QFont font;
        font.setFamily(QString::fromUtf8("Arial"));
        font.setPointSize(12);
        Dialogcgasto->setFont(font);
        label = new QLabel(Dialogcgasto);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(180, 10, 261, 31));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Arial"));
        font1.setPointSize(24);
        font1.setBold(true);
        font1.setWeight(75);
        label->setFont(font1);
        pushButton_2 = new QPushButton(Dialogcgasto);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(280, 270, 75, 23));
        label_2 = new QLabel(Dialogcgasto);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(10, 60, 81, 16));
        lineEdit = new QLineEdit(Dialogcgasto);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(90, 57, 51, 20));
        pushButton = new QPushButton(Dialogcgasto);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(146, 54, 75, 23));
        tableWidget = new QTableWidget(Dialogcgasto);
        if (tableWidget->columnCount() < 6)
            tableWidget->setColumnCount(6);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(5, __qtablewidgetitem5);
        if (tableWidget->rowCount() < 4)
            tableWidget->setRowCount(4);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(0, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(1, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(2, __qtablewidgetitem8);
        QTableWidgetItem *__qtablewidgetitem9 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(3, __qtablewidgetitem9);
        QTableWidgetItem *__qtablewidgetitem10 = new QTableWidgetItem();
        tableWidget->setItem(0, 0, __qtablewidgetitem10);
        QTableWidgetItem *__qtablewidgetitem11 = new QTableWidgetItem();
        tableWidget->setItem(0, 1, __qtablewidgetitem11);
        QTableWidgetItem *__qtablewidgetitem12 = new QTableWidgetItem();
        tableWidget->setItem(0, 2, __qtablewidgetitem12);
        QTableWidgetItem *__qtablewidgetitem13 = new QTableWidgetItem();
        tableWidget->setItem(0, 3, __qtablewidgetitem13);
        QTableWidgetItem *__qtablewidgetitem14 = new QTableWidgetItem();
        tableWidget->setItem(0, 4, __qtablewidgetitem14);
        QTableWidgetItem *__qtablewidgetitem15 = new QTableWidgetItem();
        tableWidget->setItem(0, 5, __qtablewidgetitem15);
        QTableWidgetItem *__qtablewidgetitem16 = new QTableWidgetItem();
        tableWidget->setItem(1, 0, __qtablewidgetitem16);
        QTableWidgetItem *__qtablewidgetitem17 = new QTableWidgetItem();
        tableWidget->setItem(1, 1, __qtablewidgetitem17);
        QTableWidgetItem *__qtablewidgetitem18 = new QTableWidgetItem();
        tableWidget->setItem(1, 2, __qtablewidgetitem18);
        QTableWidgetItem *__qtablewidgetitem19 = new QTableWidgetItem();
        tableWidget->setItem(1, 3, __qtablewidgetitem19);
        QTableWidgetItem *__qtablewidgetitem20 = new QTableWidgetItem();
        tableWidget->setItem(1, 4, __qtablewidgetitem20);
        QTableWidgetItem *__qtablewidgetitem21 = new QTableWidgetItem();
        tableWidget->setItem(1, 5, __qtablewidgetitem21);
        QTableWidgetItem *__qtablewidgetitem22 = new QTableWidgetItem();
        tableWidget->setItem(2, 0, __qtablewidgetitem22);
        QTableWidgetItem *__qtablewidgetitem23 = new QTableWidgetItem();
        tableWidget->setItem(2, 1, __qtablewidgetitem23);
        QTableWidgetItem *__qtablewidgetitem24 = new QTableWidgetItem();
        tableWidget->setItem(2, 2, __qtablewidgetitem24);
        QTableWidgetItem *__qtablewidgetitem25 = new QTableWidgetItem();
        tableWidget->setItem(2, 3, __qtablewidgetitem25);
        QTableWidgetItem *__qtablewidgetitem26 = new QTableWidgetItem();
        tableWidget->setItem(2, 4, __qtablewidgetitem26);
        QTableWidgetItem *__qtablewidgetitem27 = new QTableWidgetItem();
        tableWidget->setItem(2, 5, __qtablewidgetitem27);
        QTableWidgetItem *__qtablewidgetitem28 = new QTableWidgetItem();
        tableWidget->setItem(3, 0, __qtablewidgetitem28);
        QTableWidgetItem *__qtablewidgetitem29 = new QTableWidgetItem();
        tableWidget->setItem(3, 1, __qtablewidgetitem29);
        QTableWidgetItem *__qtablewidgetitem30 = new QTableWidgetItem();
        tableWidget->setItem(3, 2, __qtablewidgetitem30);
        QTableWidgetItem *__qtablewidgetitem31 = new QTableWidgetItem();
        tableWidget->setItem(3, 3, __qtablewidgetitem31);
        QTableWidgetItem *__qtablewidgetitem32 = new QTableWidgetItem();
        tableWidget->setItem(3, 4, __qtablewidgetitem32);
        QTableWidgetItem *__qtablewidgetitem33 = new QTableWidgetItem();
        tableWidget->setItem(3, 5, __qtablewidgetitem33);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setGeometry(QRect(10, 80, 621, 151));

        retranslateUi(Dialogcgasto);

        QMetaObject::connectSlotsByName(Dialogcgasto);
    } // setupUi

    void retranslateUi(QDialog *Dialogcgasto)
    {
        Dialogcgasto->setWindowTitle(QCoreApplication::translate("Dialogcgasto", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("Dialogcgasto", "Consultar Gasto", nullptr));
        pushButton_2->setText(QCoreApplication::translate("Dialogcgasto", "ok", nullptr));
        label_2->setText(QCoreApplication::translate("Dialogcgasto", "Habitacion:", nullptr));
        lineEdit->setText(QString());
        pushButton->setText(QCoreApplication::translate("Dialogcgasto", "Consulta", nullptr));
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("Dialogcgasto", "ID", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("Dialogcgasto", "Cod Producto", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QCoreApplication::translate("Dialogcgasto", "Costo", nullptr));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QCoreApplication::translate("Dialogcgasto", "Cantidad", nullptr));
        QTableWidgetItem *___qtablewidgetitem4 = tableWidget->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QCoreApplication::translate("Dialogcgasto", "Descripcion", nullptr));
        QTableWidgetItem *___qtablewidgetitem5 = tableWidget->horizontalHeaderItem(5);
        ___qtablewidgetitem5->setText(QCoreApplication::translate("Dialogcgasto", "Total", nullptr));
        QTableWidgetItem *___qtablewidgetitem6 = tableWidget->verticalHeaderItem(0);
        ___qtablewidgetitem6->setText(QCoreApplication::translate("Dialogcgasto", "1", nullptr));
        QTableWidgetItem *___qtablewidgetitem7 = tableWidget->verticalHeaderItem(1);
        ___qtablewidgetitem7->setText(QCoreApplication::translate("Dialogcgasto", "2", nullptr));
        QTableWidgetItem *___qtablewidgetitem8 = tableWidget->verticalHeaderItem(2);
        ___qtablewidgetitem8->setText(QCoreApplication::translate("Dialogcgasto", "3", nullptr));
        QTableWidgetItem *___qtablewidgetitem9 = tableWidget->verticalHeaderItem(3);
        ___qtablewidgetitem9->setText(QCoreApplication::translate("Dialogcgasto", "4", nullptr));

        const bool __sortingEnabled = tableWidget->isSortingEnabled();
        tableWidget->setSortingEnabled(false);
        QTableWidgetItem *___qtablewidgetitem10 = tableWidget->item(0, 0);
        ___qtablewidgetitem10->setText(QCoreApplication::translate("Dialogcgasto", "55", nullptr));
        QTableWidgetItem *___qtablewidgetitem11 = tableWidget->item(0, 1);
        ___qtablewidgetitem11->setText(QCoreApplication::translate("Dialogcgasto", "665", nullptr));
        QTableWidgetItem *___qtablewidgetitem12 = tableWidget->item(0, 2);
        ___qtablewidgetitem12->setText(QCoreApplication::translate("Dialogcgasto", "100", nullptr));
        QTableWidgetItem *___qtablewidgetitem13 = tableWidget->item(0, 3);
        ___qtablewidgetitem13->setText(QCoreApplication::translate("Dialogcgasto", "1", nullptr));
        QTableWidgetItem *___qtablewidgetitem14 = tableWidget->item(0, 4);
        ___qtablewidgetitem14->setText(QCoreApplication::translate("Dialogcgasto", "Coca Cola 2.5L", nullptr));
        QTableWidgetItem *___qtablewidgetitem15 = tableWidget->item(0, 5);
        ___qtablewidgetitem15->setText(QCoreApplication::translate("Dialogcgasto", "100", nullptr));
        QTableWidgetItem *___qtablewidgetitem16 = tableWidget->item(1, 0);
        ___qtablewidgetitem16->setText(QCoreApplication::translate("Dialogcgasto", "65", nullptr));
        QTableWidgetItem *___qtablewidgetitem17 = tableWidget->item(1, 1);
        ___qtablewidgetitem17->setText(QCoreApplication::translate("Dialogcgasto", "121", nullptr));
        QTableWidgetItem *___qtablewidgetitem18 = tableWidget->item(1, 2);
        ___qtablewidgetitem18->setText(QCoreApplication::translate("Dialogcgasto", "56", nullptr));
        QTableWidgetItem *___qtablewidgetitem19 = tableWidget->item(1, 3);
        ___qtablewidgetitem19->setText(QCoreApplication::translate("Dialogcgasto", "6", nullptr));
        QTableWidgetItem *___qtablewidgetitem20 = tableWidget->item(1, 4);
        ___qtablewidgetitem20->setText(QCoreApplication::translate("Dialogcgasto", "Cafe Mediano", nullptr));
        QTableWidgetItem *___qtablewidgetitem21 = tableWidget->item(1, 5);
        ___qtablewidgetitem21->setText(QCoreApplication::translate("Dialogcgasto", "336", nullptr));
        QTableWidgetItem *___qtablewidgetitem22 = tableWidget->item(2, 0);
        ___qtablewidgetitem22->setText(QCoreApplication::translate("Dialogcgasto", "72", nullptr));
        QTableWidgetItem *___qtablewidgetitem23 = tableWidget->item(2, 1);
        ___qtablewidgetitem23->setText(QCoreApplication::translate("Dialogcgasto", "335", nullptr));
        QTableWidgetItem *___qtablewidgetitem24 = tableWidget->item(2, 2);
        ___qtablewidgetitem24->setText(QCoreApplication::translate("Dialogcgasto", "70", nullptr));
        QTableWidgetItem *___qtablewidgetitem25 = tableWidget->item(2, 3);
        ___qtablewidgetitem25->setText(QCoreApplication::translate("Dialogcgasto", "2", nullptr));
        QTableWidgetItem *___qtablewidgetitem26 = tableWidget->item(2, 4);
        ___qtablewidgetitem26->setText(QCoreApplication::translate("Dialogcgasto", "Tosta JYQ", nullptr));
        QTableWidgetItem *___qtablewidgetitem27 = tableWidget->item(2, 5);
        ___qtablewidgetitem27->setText(QCoreApplication::translate("Dialogcgasto", "140", nullptr));
        QTableWidgetItem *___qtablewidgetitem28 = tableWidget->item(3, 0);
        ___qtablewidgetitem28->setText(QCoreApplication::translate("Dialogcgasto", "78", nullptr));
        QTableWidgetItem *___qtablewidgetitem29 = tableWidget->item(3, 1);
        ___qtablewidgetitem29->setText(QCoreApplication::translate("Dialogcgasto", "22", nullptr));
        QTableWidgetItem *___qtablewidgetitem30 = tableWidget->item(3, 2);
        ___qtablewidgetitem30->setText(QCoreApplication::translate("Dialogcgasto", "15", nullptr));
        QTableWidgetItem *___qtablewidgetitem31 = tableWidget->item(3, 3);
        ___qtablewidgetitem31->setText(QCoreApplication::translate("Dialogcgasto", "1", nullptr));
        QTableWidgetItem *___qtablewidgetitem32 = tableWidget->item(3, 4);
        ___qtablewidgetitem32->setText(QCoreApplication::translate("Dialogcgasto", "Adicional Crema", nullptr));
        QTableWidgetItem *___qtablewidgetitem33 = tableWidget->item(3, 5);
        ___qtablewidgetitem33->setText(QCoreApplication::translate("Dialogcgasto", "15", nullptr));
        tableWidget->setSortingEnabled(__sortingEnabled);

    } // retranslateUi

};

namespace Ui {
    class Dialogcgasto: public Ui_Dialogcgasto {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGCGASTO_H
