/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionNueva_Reserva;
    QAction *actionVer_Calendario_Reservas;
    QAction *actionCancelar_Reserva;
    QAction *actionCrear_Nueva_Habitaci_n;
    QAction *actionConsultar_Habitaci_nes;
    QAction *actionCargar_Habitacion_Mantenimiento;
    QAction *actionRecepcion;
    QAction *actionCheck_Out;
    QAction *actionNuevo_Cliente;
    QAction *actionModificar_Cliente;
    QAction *actionBuscar_Cliente;
    QAction *actionMostrar_Clientes;
    QAction *actionA_adir_Productos;
    QAction *actionDar_Alta_Producto;
    QAction *actionA_adir_Stock;
    QAction *actionMostrar_Productos;
    QAction *actionPunto_de_Venta;
    QAction *actionCargar_Empleado;
    QAction *actionMostrar_Empleados;
    QAction *actionModificar_Empleado;
    QAction *actionCargar_Gasto;
    QAction *actionConsultar_Gastos;
    QAction *actionAnular_Gasto;
    QAction *actionModificar_Gasto;
    QAction *actionConsultar_Gasto_Fecha;
    QAction *actionBuscar_Producto;
    QAction *actionCargar_Habitacion_Mantenimiento_2;
    QAction *actionMostrar_Habitacion_Mantenimiento;
    QAction *actionBuscar_Habitacion_Mantenimiento;
    QAction *actionCargar_Habitacion_Limpieza;
    QAction *actionMostrar_Habitacion_Limpieza;
    QAction *actionBuscar_Habitacion_Limpieza;
    QAction *actionRealizar_BackUp;
    QAction *actionRecuperar_BackUp;
    QWidget *centralwidget;
    QMenuBar *menubar;
    QMenu *menuReservas;
    QMenu *menuRecepci_n;
    QMenu *menuCheck_Out;
    QMenu *menuHabitaciones;
    QMenu *menuGastos;
    QMenu *menuClientes;
    QMenu *menuProductos;
    QMenu *menuEmpleados;
    QMenu *menuMantenimiento;
    QMenu *menuLimpieza;
    QMenu *menuConfugyracion;
    QMenu *menuReportes;
    QMenu *menuSalir;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->setEnabled(true);
        MainWindow->resize(874, 600);
        actionNueva_Reserva = new QAction(MainWindow);
        actionNueva_Reserva->setObjectName(QString::fromUtf8("actionNueva_Reserva"));
        actionVer_Calendario_Reservas = new QAction(MainWindow);
        actionVer_Calendario_Reservas->setObjectName(QString::fromUtf8("actionVer_Calendario_Reservas"));
        actionCancelar_Reserva = new QAction(MainWindow);
        actionCancelar_Reserva->setObjectName(QString::fromUtf8("actionCancelar_Reserva"));
        actionCrear_Nueva_Habitaci_n = new QAction(MainWindow);
        actionCrear_Nueva_Habitaci_n->setObjectName(QString::fromUtf8("actionCrear_Nueva_Habitaci_n"));
        actionConsultar_Habitaci_nes = new QAction(MainWindow);
        actionConsultar_Habitaci_nes->setObjectName(QString::fromUtf8("actionConsultar_Habitaci_nes"));
        actionCargar_Habitacion_Mantenimiento = new QAction(MainWindow);
        actionCargar_Habitacion_Mantenimiento->setObjectName(QString::fromUtf8("actionCargar_Habitacion_Mantenimiento"));
        actionRecepcion = new QAction(MainWindow);
        actionRecepcion->setObjectName(QString::fromUtf8("actionRecepcion"));
        actionCheck_Out = new QAction(MainWindow);
        actionCheck_Out->setObjectName(QString::fromUtf8("actionCheck_Out"));
        actionNuevo_Cliente = new QAction(MainWindow);
        actionNuevo_Cliente->setObjectName(QString::fromUtf8("actionNuevo_Cliente"));
        actionModificar_Cliente = new QAction(MainWindow);
        actionModificar_Cliente->setObjectName(QString::fromUtf8("actionModificar_Cliente"));
        actionBuscar_Cliente = new QAction(MainWindow);
        actionBuscar_Cliente->setObjectName(QString::fromUtf8("actionBuscar_Cliente"));
        actionMostrar_Clientes = new QAction(MainWindow);
        actionMostrar_Clientes->setObjectName(QString::fromUtf8("actionMostrar_Clientes"));
        actionA_adir_Productos = new QAction(MainWindow);
        actionA_adir_Productos->setObjectName(QString::fromUtf8("actionA_adir_Productos"));
        actionDar_Alta_Producto = new QAction(MainWindow);
        actionDar_Alta_Producto->setObjectName(QString::fromUtf8("actionDar_Alta_Producto"));
        actionA_adir_Stock = new QAction(MainWindow);
        actionA_adir_Stock->setObjectName(QString::fromUtf8("actionA_adir_Stock"));
        actionMostrar_Productos = new QAction(MainWindow);
        actionMostrar_Productos->setObjectName(QString::fromUtf8("actionMostrar_Productos"));
        actionPunto_de_Venta = new QAction(MainWindow);
        actionPunto_de_Venta->setObjectName(QString::fromUtf8("actionPunto_de_Venta"));
        actionCargar_Empleado = new QAction(MainWindow);
        actionCargar_Empleado->setObjectName(QString::fromUtf8("actionCargar_Empleado"));
        actionMostrar_Empleados = new QAction(MainWindow);
        actionMostrar_Empleados->setObjectName(QString::fromUtf8("actionMostrar_Empleados"));
        actionModificar_Empleado = new QAction(MainWindow);
        actionModificar_Empleado->setObjectName(QString::fromUtf8("actionModificar_Empleado"));
        actionCargar_Gasto = new QAction(MainWindow);
        actionCargar_Gasto->setObjectName(QString::fromUtf8("actionCargar_Gasto"));
        actionConsultar_Gastos = new QAction(MainWindow);
        actionConsultar_Gastos->setObjectName(QString::fromUtf8("actionConsultar_Gastos"));
        actionAnular_Gasto = new QAction(MainWindow);
        actionAnular_Gasto->setObjectName(QString::fromUtf8("actionAnular_Gasto"));
        actionModificar_Gasto = new QAction(MainWindow);
        actionModificar_Gasto->setObjectName(QString::fromUtf8("actionModificar_Gasto"));
        actionConsultar_Gasto_Fecha = new QAction(MainWindow);
        actionConsultar_Gasto_Fecha->setObjectName(QString::fromUtf8("actionConsultar_Gasto_Fecha"));
        actionBuscar_Producto = new QAction(MainWindow);
        actionBuscar_Producto->setObjectName(QString::fromUtf8("actionBuscar_Producto"));
        actionCargar_Habitacion_Mantenimiento_2 = new QAction(MainWindow);
        actionCargar_Habitacion_Mantenimiento_2->setObjectName(QString::fromUtf8("actionCargar_Habitacion_Mantenimiento_2"));
        actionMostrar_Habitacion_Mantenimiento = new QAction(MainWindow);
        actionMostrar_Habitacion_Mantenimiento->setObjectName(QString::fromUtf8("actionMostrar_Habitacion_Mantenimiento"));
        actionBuscar_Habitacion_Mantenimiento = new QAction(MainWindow);
        actionBuscar_Habitacion_Mantenimiento->setObjectName(QString::fromUtf8("actionBuscar_Habitacion_Mantenimiento"));
        actionCargar_Habitacion_Limpieza = new QAction(MainWindow);
        actionCargar_Habitacion_Limpieza->setObjectName(QString::fromUtf8("actionCargar_Habitacion_Limpieza"));
        actionMostrar_Habitacion_Limpieza = new QAction(MainWindow);
        actionMostrar_Habitacion_Limpieza->setObjectName(QString::fromUtf8("actionMostrar_Habitacion_Limpieza"));
        actionBuscar_Habitacion_Limpieza = new QAction(MainWindow);
        actionBuscar_Habitacion_Limpieza->setObjectName(QString::fromUtf8("actionBuscar_Habitacion_Limpieza"));
        actionRealizar_BackUp = new QAction(MainWindow);
        actionRealizar_BackUp->setObjectName(QString::fromUtf8("actionRealizar_BackUp"));
        actionRecuperar_BackUp = new QAction(MainWindow);
        actionRecuperar_BackUp->setObjectName(QString::fromUtf8("actionRecuperar_BackUp"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setEnabled(true);
        menubar->setGeometry(QRect(0, 0, 874, 21));
        menuReservas = new QMenu(menubar);
        menuReservas->setObjectName(QString::fromUtf8("menuReservas"));
        menuRecepci_n = new QMenu(menubar);
        menuRecepci_n->setObjectName(QString::fromUtf8("menuRecepci_n"));
        menuCheck_Out = new QMenu(menubar);
        menuCheck_Out->setObjectName(QString::fromUtf8("menuCheck_Out"));
        menuHabitaciones = new QMenu(menubar);
        menuHabitaciones->setObjectName(QString::fromUtf8("menuHabitaciones"));
        menuGastos = new QMenu(menuHabitaciones);
        menuGastos->setObjectName(QString::fromUtf8("menuGastos"));
        menuClientes = new QMenu(menubar);
        menuClientes->setObjectName(QString::fromUtf8("menuClientes"));
        menuProductos = new QMenu(menubar);
        menuProductos->setObjectName(QString::fromUtf8("menuProductos"));
        menuEmpleados = new QMenu(menubar);
        menuEmpleados->setObjectName(QString::fromUtf8("menuEmpleados"));
        menuMantenimiento = new QMenu(menubar);
        menuMantenimiento->setObjectName(QString::fromUtf8("menuMantenimiento"));
        menuLimpieza = new QMenu(menubar);
        menuLimpieza->setObjectName(QString::fromUtf8("menuLimpieza"));
        menuConfugyracion = new QMenu(menubar);
        menuConfugyracion->setObjectName(QString::fromUtf8("menuConfugyracion"));
        menuReportes = new QMenu(menubar);
        menuReportes->setObjectName(QString::fromUtf8("menuReportes"));
        menuSalir = new QMenu(menubar);
        menuSalir->setObjectName(QString::fromUtf8("menuSalir"));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        menubar->addAction(menuReservas->menuAction());
        menubar->addAction(menuRecepci_n->menuAction());
        menubar->addAction(menuCheck_Out->menuAction());
        menubar->addAction(menuHabitaciones->menuAction());
        menubar->addAction(menuClientes->menuAction());
        menubar->addAction(menuProductos->menuAction());
        menubar->addAction(menuEmpleados->menuAction());
        menubar->addAction(menuMantenimiento->menuAction());
        menubar->addAction(menuLimpieza->menuAction());
        menubar->addAction(menuConfugyracion->menuAction());
        menubar->addAction(menuReportes->menuAction());
        menubar->addAction(menuSalir->menuAction());
        menuReservas->addAction(actionNueva_Reserva);
        menuReservas->addAction(actionCancelar_Reserva);
        menuReservas->addSeparator();
        menuReservas->addAction(actionVer_Calendario_Reservas);
        menuHabitaciones->addAction(actionCrear_Nueva_Habitaci_n);
        menuHabitaciones->addAction(actionConsultar_Habitaci_nes);
        menuHabitaciones->addAction(menuGastos->menuAction());
        menuHabitaciones->addAction(actionCargar_Habitacion_Mantenimiento);
        menuHabitaciones->addAction(actionRecepcion);
        menuHabitaciones->addAction(actionCheck_Out);
        menuGastos->addAction(actionCargar_Gasto);
        menuGastos->addAction(actionModificar_Gasto);
        menuGastos->addAction(actionAnular_Gasto);
        menuGastos->addSeparator();
        menuGastos->addAction(actionConsultar_Gastos);
        menuGastos->addAction(actionConsultar_Gasto_Fecha);
        menuClientes->addAction(actionNuevo_Cliente);
        menuClientes->addAction(actionModificar_Cliente);
        menuClientes->addAction(actionBuscar_Cliente);
        menuClientes->addAction(actionMostrar_Clientes);
        menuProductos->addAction(actionA_adir_Productos);
        menuProductos->addAction(actionA_adir_Stock);
        menuProductos->addAction(actionBuscar_Producto);
        menuProductos->addAction(actionMostrar_Productos);
        menuProductos->addAction(actionDar_Alta_Producto);
        menuProductos->addAction(actionPunto_de_Venta);
        menuEmpleados->addAction(actionCargar_Empleado);
        menuEmpleados->addAction(actionMostrar_Empleados);
        menuEmpleados->addAction(actionModificar_Empleado);
        menuMantenimiento->addAction(actionCargar_Habitacion_Mantenimiento_2);
        menuMantenimiento->addAction(actionMostrar_Habitacion_Mantenimiento);
        menuMantenimiento->addAction(actionBuscar_Habitacion_Mantenimiento);
        menuLimpieza->addAction(actionCargar_Habitacion_Limpieza);
        menuLimpieza->addAction(actionMostrar_Habitacion_Limpieza);
        menuLimpieza->addAction(actionBuscar_Habitacion_Limpieza);
        menuConfugyracion->addAction(actionRealizar_BackUp);
        menuConfugyracion->addAction(actionRecuperar_BackUp);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "Hotel Pana", nullptr));
        actionNueva_Reserva->setText(QCoreApplication::translate("MainWindow", "Nueva Reserva", nullptr));
        actionVer_Calendario_Reservas->setText(QCoreApplication::translate("MainWindow", "Ver Calendario Reservas", nullptr));
        actionCancelar_Reserva->setText(QCoreApplication::translate("MainWindow", "Cancelar Reserva", nullptr));
        actionCrear_Nueva_Habitaci_n->setText(QCoreApplication::translate("MainWindow", "Crear Nueva Habitaci\303\263n", nullptr));
        actionConsultar_Habitaci_nes->setText(QCoreApplication::translate("MainWindow", "Consultar Habitaci\303\263nes", nullptr));
        actionCargar_Habitacion_Mantenimiento->setText(QCoreApplication::translate("MainWindow", "Cargar Habitacion Mantenimiento", nullptr));
        actionRecepcion->setText(QCoreApplication::translate("MainWindow", "Recepcion", nullptr));
        actionCheck_Out->setText(QCoreApplication::translate("MainWindow", "Check-Out", nullptr));
        actionNuevo_Cliente->setText(QCoreApplication::translate("MainWindow", "Nuevo Cliente", nullptr));
        actionModificar_Cliente->setText(QCoreApplication::translate("MainWindow", "Modificar Cliente", nullptr));
        actionBuscar_Cliente->setText(QCoreApplication::translate("MainWindow", "Buscar Cliente", nullptr));
        actionMostrar_Clientes->setText(QCoreApplication::translate("MainWindow", "Mostrar Clientes", nullptr));
        actionA_adir_Productos->setText(QCoreApplication::translate("MainWindow", "A\303\261adir Productos", nullptr));
        actionDar_Alta_Producto->setText(QCoreApplication::translate("MainWindow", "Baja Producto", nullptr));
        actionA_adir_Stock->setText(QCoreApplication::translate("MainWindow", "A\303\261adir Stock", nullptr));
        actionMostrar_Productos->setText(QCoreApplication::translate("MainWindow", "Mostrar Productos", nullptr));
        actionPunto_de_Venta->setText(QCoreApplication::translate("MainWindow", "Punto de Venta", nullptr));
        actionCargar_Empleado->setText(QCoreApplication::translate("MainWindow", "Cargar Empleado", nullptr));
        actionMostrar_Empleados->setText(QCoreApplication::translate("MainWindow", "Mostrar Empleados", nullptr));
        actionModificar_Empleado->setText(QCoreApplication::translate("MainWindow", "Modificar Empleado", nullptr));
        actionCargar_Gasto->setText(QCoreApplication::translate("MainWindow", "Cargar Gasto", nullptr));
        actionConsultar_Gastos->setText(QCoreApplication::translate("MainWindow", "Consultar Gastos", nullptr));
        actionAnular_Gasto->setText(QCoreApplication::translate("MainWindow", "Anular Gasto", nullptr));
        actionModificar_Gasto->setText(QCoreApplication::translate("MainWindow", "Modificar Gasto", nullptr));
        actionConsultar_Gasto_Fecha->setText(QCoreApplication::translate("MainWindow", "Consultar Gasto Fecha", nullptr));
        actionBuscar_Producto->setText(QCoreApplication::translate("MainWindow", "Buscar Producto", nullptr));
        actionCargar_Habitacion_Mantenimiento_2->setText(QCoreApplication::translate("MainWindow", "Cargar Habitacion Mantenimiento", nullptr));
        actionMostrar_Habitacion_Mantenimiento->setText(QCoreApplication::translate("MainWindow", "Mostrar Habitacion Mantenimiento", nullptr));
        actionBuscar_Habitacion_Mantenimiento->setText(QCoreApplication::translate("MainWindow", "Buscar Habitacion Mantenimiento", nullptr));
        actionCargar_Habitacion_Limpieza->setText(QCoreApplication::translate("MainWindow", "Cargar Habitacion Limpieza", nullptr));
        actionMostrar_Habitacion_Limpieza->setText(QCoreApplication::translate("MainWindow", "Mostrar Habitacion Limpieza", nullptr));
        actionBuscar_Habitacion_Limpieza->setText(QCoreApplication::translate("MainWindow", "Buscar Habitacion Limpieza", nullptr));
        actionRealizar_BackUp->setText(QCoreApplication::translate("MainWindow", "Realizar BackUp", nullptr));
        actionRecuperar_BackUp->setText(QCoreApplication::translate("MainWindow", "Recuperar BackUp", nullptr));
        menuReservas->setTitle(QCoreApplication::translate("MainWindow", "Reservas", nullptr));
        menuRecepci_n->setTitle(QCoreApplication::translate("MainWindow", "Recepci\303\263n", nullptr));
        menuCheck_Out->setTitle(QCoreApplication::translate("MainWindow", "Check-Out", nullptr));
        menuHabitaciones->setTitle(QCoreApplication::translate("MainWindow", "Habitaciones", nullptr));
        menuGastos->setTitle(QCoreApplication::translate("MainWindow", "Gastos", nullptr));
        menuClientes->setTitle(QCoreApplication::translate("MainWindow", "Clientes", nullptr));
        menuProductos->setTitle(QCoreApplication::translate("MainWindow", "Productos", nullptr));
        menuEmpleados->setTitle(QCoreApplication::translate("MainWindow", "Empleados", nullptr));
        menuMantenimiento->setTitle(QCoreApplication::translate("MainWindow", "Mantenimiento", nullptr));
        menuLimpieza->setTitle(QCoreApplication::translate("MainWindow", "Limpieza", nullptr));
        menuConfugyracion->setTitle(QCoreApplication::translate("MainWindow", "Configuraci\303\263n", nullptr));
        menuReportes->setTitle(QCoreApplication::translate("MainWindow", "Reportes", nullptr));
        menuSalir->setTitle(QCoreApplication::translate("MainWindow", "Salir", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
