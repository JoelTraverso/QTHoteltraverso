/********************************************************************************
** Form generated from reading UI file 'dialognuevahabitacion.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGNUEVAHABITACION_H
#define UI_DIALOGNUEVAHABITACION_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_DialogNuevaHabitacion
{
public:
    QDialogButtonBox *buttonBox;
    QLabel *label_8;
    QLabel *label;
    QLineEdit *lineEdit_nhabitacion;
    QLabel *label_2;
    QComboBox *comboBox_thabitacion;
    QPushButton *pushButton_guardar;

    void setupUi(QDialog *DialogNuevaHabitacion)
    {
        if (DialogNuevaHabitacion->objectName().isEmpty())
            DialogNuevaHabitacion->setObjectName(QString::fromUtf8("DialogNuevaHabitacion"));
        DialogNuevaHabitacion->resize(503, 249);
        QFont font;
        font.setFamily(QString::fromUtf8("Arial"));
        font.setPointSize(12);
        DialogNuevaHabitacion->setFont(font);
        buttonBox = new QDialogButtonBox(DialogNuevaHabitacion);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(140, 200, 171, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        label_8 = new QLabel(DialogNuevaHabitacion);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(110, 10, 291, 41));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Arial"));
        font1.setPointSize(24);
        font1.setBold(true);
        font1.setWeight(75);
        label_8->setFont(font1);
        label = new QLabel(DialogNuevaHabitacion);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(30, 90, 101, 16));
        lineEdit_nhabitacion = new QLineEdit(DialogNuevaHabitacion);
        lineEdit_nhabitacion->setObjectName(QString::fromUtf8("lineEdit_nhabitacion"));
        lineEdit_nhabitacion->setGeometry(QRect(130, 90, 41, 20));
        label_2 = new QLabel(DialogNuevaHabitacion);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(30, 130, 111, 16));
        comboBox_thabitacion = new QComboBox(DialogNuevaHabitacion);
        comboBox_thabitacion->addItem(QString());
        comboBox_thabitacion->addItem(QString());
        comboBox_thabitacion->addItem(QString());
        comboBox_thabitacion->addItem(QString());
        comboBox_thabitacion->setObjectName(QString::fromUtf8("comboBox_thabitacion"));
        comboBox_thabitacion->setGeometry(QRect(145, 127, 151, 21));
        pushButton_guardar = new QPushButton(DialogNuevaHabitacion);
        pushButton_guardar->setObjectName(QString::fromUtf8("pushButton_guardar"));
        pushButton_guardar->setGeometry(QRect(350, 160, 75, 23));

        retranslateUi(DialogNuevaHabitacion);
        QObject::connect(buttonBox, SIGNAL(accepted()), DialogNuevaHabitacion, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), DialogNuevaHabitacion, SLOT(reject()));

        QMetaObject::connectSlotsByName(DialogNuevaHabitacion);
    } // setupUi

    void retranslateUi(QDialog *DialogNuevaHabitacion)
    {
        DialogNuevaHabitacion->setWindowTitle(QCoreApplication::translate("DialogNuevaHabitacion", "Nueva Habitacion", nullptr));
        label_8->setText(QCoreApplication::translate("DialogNuevaHabitacion", "Nueva Habitacion", nullptr));
        label->setText(QCoreApplication::translate("DialogNuevaHabitacion", "N\302\260 Habitacion", nullptr));
        lineEdit_nhabitacion->setText(QString());
        label_2->setText(QCoreApplication::translate("DialogNuevaHabitacion", "Tipo Habitaci\303\263n", nullptr));
        comboBox_thabitacion->setItemText(0, QCoreApplication::translate("DialogNuevaHabitacion", "Suite Presidencial", nullptr));
        comboBox_thabitacion->setItemText(1, QCoreApplication::translate("DialogNuevaHabitacion", "Master Suite", nullptr));
        comboBox_thabitacion->setItemText(2, QCoreApplication::translate("DialogNuevaHabitacion", "Suite Standar", nullptr));
        comboBox_thabitacion->setItemText(3, QCoreApplication::translate("DialogNuevaHabitacion", "Regular", nullptr));

        pushButton_guardar->setText(QCoreApplication::translate("DialogNuevaHabitacion", "PushButton", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DialogNuevaHabitacion: public Ui_DialogNuevaHabitacion {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGNUEVAHABITACION_H
