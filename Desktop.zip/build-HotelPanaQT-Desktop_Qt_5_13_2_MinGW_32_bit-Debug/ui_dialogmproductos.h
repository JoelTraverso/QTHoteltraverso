/********************************************************************************
** Form generated from reading UI file 'dialogmproductos.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGMPRODUCTOS_H
#define UI_DIALOGMPRODUCTOS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>

QT_BEGIN_NAMESPACE

class Ui_DialogMproductos
{
public:
    QLabel *label;
    QTableWidget *tableWidget;
    QPushButton *pushButton;

    void setupUi(QDialog *DialogMproductos)
    {
        if (DialogMproductos->objectName().isEmpty())
            DialogMproductos->setObjectName(QString::fromUtf8("DialogMproductos"));
        DialogMproductos->resize(849, 312);
        QSizePolicy sizePolicy(QSizePolicy::Maximum, QSizePolicy::Maximum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(DialogMproductos->sizePolicy().hasHeightForWidth());
        DialogMproductos->setSizePolicy(sizePolicy);
        QFont font;
        font.setFamily(QString::fromUtf8("Arial"));
        font.setPointSize(12);
        DialogMproductos->setFont(font);
        label = new QLabel(DialogMproductos);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(290, 10, 301, 31));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Arial"));
        font1.setPointSize(24);
        font1.setBold(true);
        font1.setWeight(75);
        label->setFont(font1);
        tableWidget = new QTableWidget(DialogMproductos);
        if (tableWidget->columnCount() < 5)
            tableWidget->setColumnCount(5);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        if (tableWidget->rowCount() < 5)
            tableWidget->setRowCount(5);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(0, __qtablewidgetitem5);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(1, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(2, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(3, __qtablewidgetitem8);
        QTableWidgetItem *__qtablewidgetitem9 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(4, __qtablewidgetitem9);
        QTableWidgetItem *__qtablewidgetitem10 = new QTableWidgetItem();
        tableWidget->setItem(0, 0, __qtablewidgetitem10);
        QTableWidgetItem *__qtablewidgetitem11 = new QTableWidgetItem();
        tableWidget->setItem(0, 1, __qtablewidgetitem11);
        QTableWidgetItem *__qtablewidgetitem12 = new QTableWidgetItem();
        tableWidget->setItem(0, 2, __qtablewidgetitem12);
        QTableWidgetItem *__qtablewidgetitem13 = new QTableWidgetItem();
        tableWidget->setItem(0, 3, __qtablewidgetitem13);
        QTableWidgetItem *__qtablewidgetitem14 = new QTableWidgetItem();
        tableWidget->setItem(0, 4, __qtablewidgetitem14);
        QTableWidgetItem *__qtablewidgetitem15 = new QTableWidgetItem();
        tableWidget->setItem(1, 0, __qtablewidgetitem15);
        QTableWidgetItem *__qtablewidgetitem16 = new QTableWidgetItem();
        tableWidget->setItem(1, 1, __qtablewidgetitem16);
        QTableWidgetItem *__qtablewidgetitem17 = new QTableWidgetItem();
        tableWidget->setItem(1, 2, __qtablewidgetitem17);
        QTableWidgetItem *__qtablewidgetitem18 = new QTableWidgetItem();
        tableWidget->setItem(1, 3, __qtablewidgetitem18);
        QTableWidgetItem *__qtablewidgetitem19 = new QTableWidgetItem();
        tableWidget->setItem(1, 4, __qtablewidgetitem19);
        QTableWidgetItem *__qtablewidgetitem20 = new QTableWidgetItem();
        tableWidget->setItem(2, 0, __qtablewidgetitem20);
        QTableWidgetItem *__qtablewidgetitem21 = new QTableWidgetItem();
        tableWidget->setItem(2, 1, __qtablewidgetitem21);
        QTableWidgetItem *__qtablewidgetitem22 = new QTableWidgetItem();
        tableWidget->setItem(2, 2, __qtablewidgetitem22);
        QTableWidgetItem *__qtablewidgetitem23 = new QTableWidgetItem();
        tableWidget->setItem(2, 3, __qtablewidgetitem23);
        QTableWidgetItem *__qtablewidgetitem24 = new QTableWidgetItem();
        tableWidget->setItem(2, 4, __qtablewidgetitem24);
        QTableWidgetItem *__qtablewidgetitem25 = new QTableWidgetItem();
        tableWidget->setItem(3, 0, __qtablewidgetitem25);
        QTableWidgetItem *__qtablewidgetitem26 = new QTableWidgetItem();
        tableWidget->setItem(3, 1, __qtablewidgetitem26);
        QTableWidgetItem *__qtablewidgetitem27 = new QTableWidgetItem();
        tableWidget->setItem(3, 2, __qtablewidgetitem27);
        QTableWidgetItem *__qtablewidgetitem28 = new QTableWidgetItem();
        tableWidget->setItem(3, 3, __qtablewidgetitem28);
        QTableWidgetItem *__qtablewidgetitem29 = new QTableWidgetItem();
        tableWidget->setItem(3, 4, __qtablewidgetitem29);
        QTableWidgetItem *__qtablewidgetitem30 = new QTableWidgetItem();
        tableWidget->setItem(4, 0, __qtablewidgetitem30);
        QTableWidgetItem *__qtablewidgetitem31 = new QTableWidgetItem();
        tableWidget->setItem(4, 1, __qtablewidgetitem31);
        QTableWidgetItem *__qtablewidgetitem32 = new QTableWidgetItem();
        tableWidget->setItem(4, 2, __qtablewidgetitem32);
        QTableWidgetItem *__qtablewidgetitem33 = new QTableWidgetItem();
        tableWidget->setItem(4, 3, __qtablewidgetitem33);
        QTableWidgetItem *__qtablewidgetitem34 = new QTableWidgetItem();
        tableWidget->setItem(4, 4, __qtablewidgetitem34);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setGeometry(QRect(10, 60, 821, 180));
        QSizePolicy sizePolicy1(QSizePolicy::Maximum, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(tableWidget->sizePolicy().hasHeightForWidth());
        tableWidget->setSizePolicy(sizePolicy1);
        tableWidget->setAutoScrollMargin(22);
        tableWidget->setAlternatingRowColors(true);
        tableWidget->setShowGrid(true);
        tableWidget->horizontalHeader()->setDefaultSectionSize(160);
        tableWidget->horizontalHeader()->setHighlightSections(true);
        pushButton = new QPushButton(DialogMproductos);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(380, 270, 75, 23));

        retranslateUi(DialogMproductos);

        QMetaObject::connectSlotsByName(DialogMproductos);
    } // setupUi

    void retranslateUi(QDialog *DialogMproductos)
    {
        DialogMproductos->setWindowTitle(QCoreApplication::translate("DialogMproductos", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("DialogMproductos", "Mostrar Productos", nullptr));
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("DialogMproductos", "ID", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("DialogMproductos", "Nombre", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QCoreApplication::translate("DialogMproductos", "Precio", nullptr));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QCoreApplication::translate("DialogMproductos", "Stock", nullptr));
        QTableWidgetItem *___qtablewidgetitem4 = tableWidget->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QCoreApplication::translate("DialogMproductos", "Estado", nullptr));
        QTableWidgetItem *___qtablewidgetitem5 = tableWidget->verticalHeaderItem(0);
        ___qtablewidgetitem5->setText(QCoreApplication::translate("DialogMproductos", "1", nullptr));
        QTableWidgetItem *___qtablewidgetitem6 = tableWidget->verticalHeaderItem(1);
        ___qtablewidgetitem6->setText(QCoreApplication::translate("DialogMproductos", "2", nullptr));
        QTableWidgetItem *___qtablewidgetitem7 = tableWidget->verticalHeaderItem(2);
        ___qtablewidgetitem7->setText(QCoreApplication::translate("DialogMproductos", "3", nullptr));
        QTableWidgetItem *___qtablewidgetitem8 = tableWidget->verticalHeaderItem(3);
        ___qtablewidgetitem8->setText(QCoreApplication::translate("DialogMproductos", "4", nullptr));
        QTableWidgetItem *___qtablewidgetitem9 = tableWidget->verticalHeaderItem(4);
        ___qtablewidgetitem9->setText(QCoreApplication::translate("DialogMproductos", "5", nullptr));

        const bool __sortingEnabled = tableWidget->isSortingEnabled();
        tableWidget->setSortingEnabled(false);
        QTableWidgetItem *___qtablewidgetitem10 = tableWidget->item(0, 0);
        ___qtablewidgetitem10->setText(QCoreApplication::translate("DialogMproductos", "231", nullptr));
        QTableWidgetItem *___qtablewidgetitem11 = tableWidget->item(0, 1);
        ___qtablewidgetitem11->setText(QCoreApplication::translate("DialogMproductos", "Coca Cola 2.25L", nullptr));
        QTableWidgetItem *___qtablewidgetitem12 = tableWidget->item(0, 2);
        ___qtablewidgetitem12->setText(QCoreApplication::translate("DialogMproductos", "150", nullptr));
        QTableWidgetItem *___qtablewidgetitem13 = tableWidget->item(0, 3);
        ___qtablewidgetitem13->setText(QCoreApplication::translate("DialogMproductos", "220", nullptr));
        QTableWidgetItem *___qtablewidgetitem14 = tableWidget->item(0, 4);
        ___qtablewidgetitem14->setText(QCoreApplication::translate("DialogMproductos", "Activo", nullptr));
        QTableWidgetItem *___qtablewidgetitem15 = tableWidget->item(1, 0);
        ___qtablewidgetitem15->setText(QCoreApplication::translate("DialogMproductos", "182", nullptr));
        QTableWidgetItem *___qtablewidgetitem16 = tableWidget->item(1, 1);
        ___qtablewidgetitem16->setText(QCoreApplication::translate("DialogMproductos", "RedBull 398cm3", nullptr));
        QTableWidgetItem *___qtablewidgetitem17 = tableWidget->item(1, 2);
        ___qtablewidgetitem17->setText(QCoreApplication::translate("DialogMproductos", "60", nullptr));
        QTableWidgetItem *___qtablewidgetitem18 = tableWidget->item(1, 3);
        ___qtablewidgetitem18->setText(QCoreApplication::translate("DialogMproductos", "500", nullptr));
        QTableWidgetItem *___qtablewidgetitem19 = tableWidget->item(1, 4);
        ___qtablewidgetitem19->setText(QCoreApplication::translate("DialogMproductos", "Activo", nullptr));
        QTableWidgetItem *___qtablewidgetitem20 = tableWidget->item(2, 0);
        ___qtablewidgetitem20->setText(QCoreApplication::translate("DialogMproductos", "21", nullptr));
        QTableWidgetItem *___qtablewidgetitem21 = tableWidget->item(2, 1);
        ___qtablewidgetitem21->setText(QCoreApplication::translate("DialogMproductos", "Pizza Muzzarella", nullptr));
        QTableWidgetItem *___qtablewidgetitem22 = tableWidget->item(2, 2);
        ___qtablewidgetitem22->setText(QCoreApplication::translate("DialogMproductos", "250", nullptr));
        QTableWidgetItem *___qtablewidgetitem23 = tableWidget->item(2, 3);
        ___qtablewidgetitem23->setText(QCoreApplication::translate("DialogMproductos", "12", nullptr));
        QTableWidgetItem *___qtablewidgetitem24 = tableWidget->item(2, 4);
        ___qtablewidgetitem24->setText(QCoreApplication::translate("DialogMproductos", "Descontinuado", nullptr));
        QTableWidgetItem *___qtablewidgetitem25 = tableWidget->item(3, 0);
        ___qtablewidgetitem25->setText(QCoreApplication::translate("DialogMproductos", "988", nullptr));
        QTableWidgetItem *___qtablewidgetitem26 = tableWidget->item(3, 1);
        ___qtablewidgetitem26->setText(QCoreApplication::translate("DialogMproductos", "Whisky Chivas Regal 1L", nullptr));
        QTableWidgetItem *___qtablewidgetitem27 = tableWidget->item(3, 2);
        ___qtablewidgetitem27->setText(QCoreApplication::translate("DialogMproductos", "1500", nullptr));
        QTableWidgetItem *___qtablewidgetitem28 = tableWidget->item(3, 3);
        ___qtablewidgetitem28->setText(QCoreApplication::translate("DialogMproductos", "8", nullptr));
        QTableWidgetItem *___qtablewidgetitem29 = tableWidget->item(3, 4);
        ___qtablewidgetitem29->setText(QCoreApplication::translate("DialogMproductos", "Activo", nullptr));
        QTableWidgetItem *___qtablewidgetitem30 = tableWidget->item(4, 0);
        ___qtablewidgetitem30->setText(QCoreApplication::translate("DialogMproductos", "7", nullptr));
        QTableWidgetItem *___qtablewidgetitem31 = tableWidget->item(4, 1);
        ___qtablewidgetitem31->setText(QCoreApplication::translate("DialogMproductos", "Pepsi 600cm3", nullptr));
        QTableWidgetItem *___qtablewidgetitem32 = tableWidget->item(4, 2);
        ___qtablewidgetitem32->setText(QCoreApplication::translate("DialogMproductos", "75", nullptr));
        QTableWidgetItem *___qtablewidgetitem33 = tableWidget->item(4, 3);
        ___qtablewidgetitem33->setText(QCoreApplication::translate("DialogMproductos", "500", nullptr));
        QTableWidgetItem *___qtablewidgetitem34 = tableWidget->item(4, 4);
        ___qtablewidgetitem34->setText(QCoreApplication::translate("DialogMproductos", "Activo", nullptr));
        tableWidget->setSortingEnabled(__sortingEnabled);

        pushButton->setText(QCoreApplication::translate("DialogMproductos", "OK", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DialogMproductos: public Ui_DialogMproductos {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGMPRODUCTOS_H
