/********************************************************************************
** Form generated from reading UI file 'dialogcempleado.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGCEMPLEADO_H
#define UI_DIALOGCEMPLEADO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QRadioButton>

QT_BEGIN_NAMESPACE

class Ui_DialogCempleado
{
public:
    QDialogButtonBox *buttonBox;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *lineEdit;
    QLabel *label_3;
    QLineEdit *lineEdit_2;
    QLabel *label_4;
    QLineEdit *lineEdit_3;
    QLabel *label_5;
    QLineEdit *lineEdit_4;
    QLabel *label_6;
    QLineEdit *lineEdit_5;
    QLabel *label_7;
    QLineEdit *lineEdit_6;
    QLabel *label_8;
    QLabel *label_9;
    QCheckBox *checkBox;
    QCheckBox *checkBox_2;
    QCheckBox *checkBox_3;
    QLabel *label_10;
    QLineEdit *lineEdit_7;
    QLabel *label_11;
    QLineEdit *lineEdit_8;
    QLabel *label_12;
    QComboBox *comboBox;
    QLabel *label_13;
    QLineEdit *lineEdit_9;
    QRadioButton *radioButton_3;
    QRadioButton *radioButton_2;
    QRadioButton *radioButton;

    void setupUi(QDialog *DialogCempleado)
    {
        if (DialogCempleado->objectName().isEmpty())
            DialogCempleado->setObjectName(QString::fromUtf8("DialogCempleado"));
        DialogCempleado->resize(500, 473);
        QFont font;
        font.setFamily(QString::fromUtf8("Arial"));
        font.setPointSize(12);
        DialogCempleado->setFont(font);
        buttonBox = new QDialogButtonBox(DialogCempleado);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(150, 430, 161, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        label = new QLabel(DialogCempleado);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(120, 0, 271, 41));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Arial"));
        font1.setPointSize(24);
        font1.setBold(true);
        font1.setWeight(75);
        label->setFont(font1);
        label_2 = new QLabel(DialogCempleado);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(10, 60, 61, 16));
        lineEdit = new QLineEdit(DialogCempleado);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(74, 57, 211, 20));
        label_3 = new QLabel(DialogCempleado);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(10, 90, 61, 16));
        lineEdit_2 = new QLineEdit(DialogCempleado);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(74, 88, 211, 20));
        label_4 = new QLabel(DialogCempleado);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(10, 120, 81, 16));
        lineEdit_3 = new QLineEdit(DialogCempleado);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(83, 118, 201, 20));
        label_5 = new QLabel(DialogCempleado);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(10, 150, 31, 16));
        lineEdit_4 = new QLineEdit(DialogCempleado);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(41, 147, 81, 20));
        label_6 = new QLabel(DialogCempleado);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(10, 180, 71, 16));
        lineEdit_5 = new QLineEdit(DialogCempleado);
        lineEdit_5->setObjectName(QString::fromUtf8("lineEdit_5"));
        lineEdit_5->setGeometry(QRect(77, 177, 131, 20));
        label_7 = new QLabel(DialogCempleado);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(10, 210, 61, 16));
        lineEdit_6 = new QLineEdit(DialogCempleado);
        lineEdit_6->setObjectName(QString::fromUtf8("lineEdit_6"));
        lineEdit_6->setGeometry(QRect(68, 207, 141, 20));
        label_8 = new QLabel(DialogCempleado);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(10, 240, 47, 13));
        label_9 = new QLabel(DialogCempleado);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(10, 270, 47, 13));
        checkBox = new QCheckBox(DialogCempleado);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        checkBox->setGeometry(QRect(60, 270, 101, 17));
        checkBox_2 = new QCheckBox(DialogCempleado);
        checkBox_2->setObjectName(QString::fromUtf8("checkBox_2"));
        checkBox_2->setGeometry(QRect(140, 270, 70, 17));
        checkBox_3 = new QCheckBox(DialogCempleado);
        checkBox_3->setObjectName(QString::fromUtf8("checkBox_3"));
        checkBox_3->setGeometry(QRect(210, 270, 70, 17));
        label_10 = new QLabel(DialogCempleado);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(10, 300, 71, 16));
        lineEdit_7 = new QLineEdit(DialogCempleado);
        lineEdit_7->setObjectName(QString::fromUtf8("lineEdit_7"));
        lineEdit_7->setGeometry(QRect(80, 298, 71, 20));
        label_11 = new QLabel(DialogCempleado);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(10, 330, 41, 16));
        lineEdit_8 = new QLineEdit(DialogCempleado);
        lineEdit_8->setObjectName(QString::fromUtf8("lineEdit_8"));
        lineEdit_8->setGeometry(QRect(48, 328, 113, 20));
        label_12 = new QLabel(DialogCempleado);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(10, 360, 51, 16));
        comboBox = new QComboBox(DialogCempleado);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(65, 354, 140, 25));
        label_13 = new QLabel(DialogCempleado);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(10, 390, 61, 16));
        lineEdit_9 = new QLineEdit(DialogCempleado);
        lineEdit_9->setObjectName(QString::fromUtf8("lineEdit_9"));
        lineEdit_9->setGeometry(QRect(69, 388, 113, 20));
        radioButton_3 = new QRadioButton(DialogCempleado);
        radioButton_3->setObjectName(QString::fromUtf8("radioButton_3"));
        radioButton_3->setGeometry(QRect(210, 240, 82, 17));
        radioButton_2 = new QRadioButton(DialogCempleado);
        radioButton_2->setObjectName(QString::fromUtf8("radioButton_2"));
        radioButton_2->setGeometry(QRect(142, 240, 61, 17));
        radioButton = new QRadioButton(DialogCempleado);
        radioButton->setObjectName(QString::fromUtf8("radioButton"));
        radioButton->setGeometry(QRect(60, 240, 82, 17));

        retranslateUi(DialogCempleado);
        QObject::connect(buttonBox, SIGNAL(accepted()), DialogCempleado, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), DialogCempleado, SLOT(reject()));

        QMetaObject::connectSlotsByName(DialogCempleado);
    } // setupUi

    void retranslateUi(QDialog *DialogCempleado)
    {
        DialogCempleado->setWindowTitle(QCoreApplication::translate("DialogCempleado", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("DialogCempleado", "Cargar Empleado", nullptr));
        label_2->setText(QCoreApplication::translate("DialogCempleado", "Nombre:", nullptr));
        label_3->setText(QCoreApplication::translate("DialogCempleado", "Apellido:", nullptr));
        lineEdit_2->setText(QString());
        label_4->setText(QCoreApplication::translate("DialogCempleado", "Direccion:", nullptr));
        lineEdit_3->setText(QString());
        label_5->setText(QCoreApplication::translate("DialogCempleado", "DNI:", nullptr));
        lineEdit_4->setText(QString());
        label_6->setText(QCoreApplication::translate("DialogCempleado", "Telefono:", nullptr));
        lineEdit_5->setText(QCoreApplication::translate("DialogCempleado", "+54", nullptr));
        label_7->setText(QCoreApplication::translate("DialogCempleado", "Celular:", nullptr));
        lineEdit_6->setText(QCoreApplication::translate("DialogCempleado", "(011)", nullptr));
        label_8->setText(QCoreApplication::translate("DialogCempleado", "Sexo:", nullptr));
        label_9->setText(QCoreApplication::translate("DialogCempleado", "Turno:", nullptr));
        checkBox->setText(QCoreApplication::translate("DialogCempleado", "Ma\303\261ana", nullptr));
        checkBox_2->setText(QCoreApplication::translate("DialogCempleado", "Tarde", nullptr));
        checkBox_3->setText(QCoreApplication::translate("DialogCempleado", "Noche", nullptr));
        label_10->setText(QCoreApplication::translate("DialogCempleado", "Sueldo: $", nullptr));
        lineEdit_7->setText(QString());
        label_11->setText(QCoreApplication::translate("DialogCempleado", "Cuil:", nullptr));
        label_12->setText(QCoreApplication::translate("DialogCempleado", "Sector:", nullptr));
        comboBox->setItemText(0, QCoreApplication::translate("DialogCempleado", "Seguridad", nullptr));
        comboBox->setItemText(1, QCoreApplication::translate("DialogCempleado", "Limpieza", nullptr));
        comboBox->setItemText(2, QCoreApplication::translate("DialogCempleado", "Administrativo", nullptr));
        comboBox->setItemText(3, QCoreApplication::translate("DialogCempleado", "Mantenimiento", nullptr));
        comboBox->setItemText(4, QCoreApplication::translate("DialogCempleado", "Otro", nullptr));

        label_13->setText(QCoreApplication::translate("DialogCempleado", "Puesto:", nullptr));
        radioButton_3->setText(QCoreApplication::translate("DialogCempleado", "Otro", nullptr));
        radioButton_2->setText(QCoreApplication::translate("DialogCempleado", "Mujer", nullptr));
        radioButton->setText(QCoreApplication::translate("DialogCempleado", "Hombre", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DialogCempleado: public Ui_DialogCempleado {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGCEMPLEADO_H
