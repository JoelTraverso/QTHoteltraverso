/********************************************************************************
** Form generated from reading UI file 'dialogcargargasto.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGCARGARGASTO_H
#define UI_DIALOGCARGARGASTO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Dialogcargargasto
{
public:
    QDialogButtonBox *buttonBox;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *lineEdit;
    QLabel *label_3;
    QLineEdit *lineEdit_2;
    QLabel *label_4;
    QLineEdit *lineEdit_3;
    QLabel *label_5;
    QPushButton *pushButton;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_10;

    void setupUi(QDialog *Dialogcargargasto)
    {
        if (Dialogcargargasto->objectName().isEmpty())
            Dialogcargargasto->setObjectName(QString::fromUtf8("Dialogcargargasto"));
        Dialogcargargasto->resize(400, 300);
        QFont font;
        font.setFamily(QString::fromUtf8("Arial"));
        font.setPointSize(12);
        Dialogcargargasto->setFont(font);
        buttonBox = new QDialogButtonBox(Dialogcargargasto);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(90, 250, 171, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        label = new QLabel(Dialogcargargasto);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(90, 10, 211, 41));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Arial"));
        font1.setPointSize(24);
        font1.setBold(true);
        font1.setWeight(75);
        label->setFont(font1);
        label_2 = new QLabel(Dialogcargargasto);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(20, 70, 81, 16));
        lineEdit = new QLineEdit(Dialogcargargasto);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(100, 68, 41, 21));
        label_3 = new QLabel(Dialogcargargasto);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(20, 100, 101, 16));
        lineEdit_2 = new QLineEdit(Dialogcargargasto);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(123, 98, 41, 20));
        label_4 = new QLabel(Dialogcargargasto);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(20, 130, 71, 16));
        lineEdit_3 = new QLineEdit(Dialogcargargasto);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(90, 127, 41, 20));
        label_5 = new QLabel(Dialogcargargasto);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(20, 160, 91, 16));
        pushButton = new QPushButton(Dialogcargargasto);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(170, 96, 75, 23));
        label_6 = new QLabel(Dialogcargargasto);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(110, 160, 261, 16));
        label_7 = new QLabel(Dialogcargargasto);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(20, 190, 91, 16));
        label_8 = new QLabel(Dialogcargargasto);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(80, 190, 51, 16));
        label_9 = new QLabel(Dialogcargargasto);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(20, 220, 51, 16));
        label_10 = new QLabel(Dialogcargargasto);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(72, 220, 61, 16));

        retranslateUi(Dialogcargargasto);
        QObject::connect(buttonBox, SIGNAL(accepted()), Dialogcargargasto, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), Dialogcargargasto, SLOT(reject()));

        QMetaObject::connectSlotsByName(Dialogcargargasto);
    } // setupUi

    void retranslateUi(QDialog *Dialogcargargasto)
    {
        Dialogcargargasto->setWindowTitle(QCoreApplication::translate("Dialogcargargasto", "Cargar Gasto", nullptr));
        label->setText(QCoreApplication::translate("Dialogcargargasto", "Cargar Gasto", nullptr));
        label_2->setText(QCoreApplication::translate("Dialogcargargasto", "Habitacion:", nullptr));
        lineEdit->setText(QString());
        label_3->setText(QCoreApplication::translate("Dialogcargargasto", "Cod Producto:", nullptr));
        lineEdit_2->setText(QString());
        label_4->setText(QCoreApplication::translate("Dialogcargargasto", "Cantidad:", nullptr));
        lineEdit_3->setText(QString());
        label_5->setText(QCoreApplication::translate("Dialogcargargasto", "Descripcion:", nullptr));
        pushButton->setText(QCoreApplication::translate("Dialogcargargasto", "Consulta", nullptr));
        label_6->setText(QCoreApplication::translate("Dialogcargargasto", "Coca Cola 2.5L", nullptr));
        label_7->setText(QCoreApplication::translate("Dialogcargargasto", "Costo: $", nullptr));
        label_8->setText(QCoreApplication::translate("Dialogcargargasto", "135", nullptr));
        label_9->setText(QCoreApplication::translate("Dialogcargargasto", "Total: $", nullptr));
        label_10->setText(QCoreApplication::translate("Dialogcargargasto", "270", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Dialogcargargasto: public Ui_Dialogcargargasto {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGCARGARGASTO_H
