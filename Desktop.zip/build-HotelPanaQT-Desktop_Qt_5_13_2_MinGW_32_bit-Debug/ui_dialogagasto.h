/********************************************************************************
** Form generated from reading UI file 'dialogagasto.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGAGASTO_H
#define UI_DIALOGAGASTO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_DialogAgasto
{
public:
    QDialogButtonBox *buttonBox;
    QLabel *label;
    QPushButton *pushButton;
    QLabel *label_11;
    QLabel *label_9;
    QLabel *label_3;
    QLabel *label_7;
    QLabel *label_4;
    QLabel *label_5;
    QLineEdit *lineEdit_4;
    QLabel *label_2;
    QLabel *label_6;
    QLabel *label_8;
    QLabel *label_10;
    QLabel *label_12;
    QLabel *label_13;
    QLabel *label_14;

    void setupUi(QDialog *DialogAgasto)
    {
        if (DialogAgasto->objectName().isEmpty())
            DialogAgasto->setObjectName(QString::fromUtf8("DialogAgasto"));
        DialogAgasto->resize(451, 332);
        QFont font;
        font.setFamily(QString::fromUtf8("Arial"));
        font.setPointSize(12);
        DialogAgasto->setFont(font);
        buttonBox = new QDialogButtonBox(DialogAgasto);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(140, 290, 161, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        label = new QLabel(DialogAgasto);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(110, 10, 201, 31));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Arial"));
        font1.setPointSize(24);
        font1.setBold(true);
        font1.setWeight(75);
        label->setFont(font1);
        pushButton = new QPushButton(DialogAgasto);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(100, 64, 75, 23));
        label_11 = new QLabel(DialogAgasto);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(30, 70, 47, 13));
        label_9 = new QLabel(DialogAgasto);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(30, 250, 51, 16));
        label_3 = new QLabel(DialogAgasto);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(30, 130, 101, 16));
        label_7 = new QLabel(DialogAgasto);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(30, 220, 61, 16));
        label_4 = new QLabel(DialogAgasto);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(30, 160, 71, 16));
        label_5 = new QLabel(DialogAgasto);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(30, 190, 91, 16));
        lineEdit_4 = new QLineEdit(DialogAgasto);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(52, 66, 41, 21));
        label_2 = new QLabel(DialogAgasto);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(30, 100, 81, 16));
        label_6 = new QLabel(DialogAgasto);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(112, 101, 47, 13));
        label_8 = new QLabel(DialogAgasto);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(133, 131, 47, 13));
        label_10 = new QLabel(DialogAgasto);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(101, 161, 47, 13));
        label_12 = new QLabel(DialogAgasto);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(121, 191, 101, 16));
        label_13 = new QLabel(DialogAgasto);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(92, 221, 47, 13));
        label_14 = new QLabel(DialogAgasto);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(80, 250, 47, 16));

        retranslateUi(DialogAgasto);
        QObject::connect(buttonBox, SIGNAL(accepted()), DialogAgasto, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), DialogAgasto, SLOT(reject()));

        QMetaObject::connectSlotsByName(DialogAgasto);
    } // setupUi

    void retranslateUi(QDialog *DialogAgasto)
    {
        DialogAgasto->setWindowTitle(QCoreApplication::translate("DialogAgasto", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("DialogAgasto", "Anular Gasto", nullptr));
        pushButton->setText(QCoreApplication::translate("DialogAgasto", "Consulta", nullptr));
        label_11->setText(QCoreApplication::translate("DialogAgasto", "ID:", nullptr));
        label_9->setText(QCoreApplication::translate("DialogAgasto", "Total: $", nullptr));
        label_3->setText(QCoreApplication::translate("DialogAgasto", "Cod Producto:", nullptr));
        label_7->setText(QCoreApplication::translate("DialogAgasto", "Costo: $", nullptr));
        label_4->setText(QCoreApplication::translate("DialogAgasto", "Cantidad:", nullptr));
        label_5->setText(QCoreApplication::translate("DialogAgasto", "Descripcion:", nullptr));
        lineEdit_4->setText(QString());
        label_2->setText(QCoreApplication::translate("DialogAgasto", "Habitacion:", nullptr));
        label_6->setText(QCoreApplication::translate("DialogAgasto", "125", nullptr));
        label_8->setText(QCoreApplication::translate("DialogAgasto", "1680", nullptr));
        label_10->setText(QCoreApplication::translate("DialogAgasto", "3", nullptr));
        label_12->setText(QCoreApplication::translate("DialogAgasto", "Alfajor Jorgito", nullptr));
        label_13->setText(QCoreApplication::translate("DialogAgasto", "55", nullptr));
        label_14->setText(QCoreApplication::translate("DialogAgasto", "165", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DialogAgasto: public Ui_DialogAgasto {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGAGASTO_H
