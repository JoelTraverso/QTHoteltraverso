/********************************************************************************
** Form generated from reading UI file 'dialogmempleados.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGMEMPLEADOS_H
#define UI_DIALOGMEMPLEADOS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>

QT_BEGIN_NAMESPACE

class Ui_DialogMempleados
{
public:
    QLabel *label;
    QTableWidget *tableWidget;
    QPushButton *pushButton;

    void setupUi(QDialog *DialogMempleados)
    {
        if (DialogMempleados->objectName().isEmpty())
            DialogMempleados->setObjectName(QString::fromUtf8("DialogMempleados"));
        DialogMempleados->resize(829, 366);
        QFont font;
        font.setFamily(QString::fromUtf8("Arial"));
        font.setPointSize(12);
        DialogMempleados->setFont(font);
        label = new QLabel(DialogMempleados);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(280, 10, 301, 41));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Arial"));
        font1.setPointSize(24);
        font1.setBold(true);
        font1.setWeight(75);
        label->setFont(font1);
        tableWidget = new QTableWidget(DialogMempleados);
        if (tableWidget->columnCount() < 6)
            tableWidget->setColumnCount(6);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(5, __qtablewidgetitem5);
        if (tableWidget->rowCount() < 5)
            tableWidget->setRowCount(5);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(0, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(1, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(2, __qtablewidgetitem8);
        QTableWidgetItem *__qtablewidgetitem9 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(3, __qtablewidgetitem9);
        QTableWidgetItem *__qtablewidgetitem10 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(4, __qtablewidgetitem10);
        QTableWidgetItem *__qtablewidgetitem11 = new QTableWidgetItem();
        tableWidget->setItem(0, 0, __qtablewidgetitem11);
        QTableWidgetItem *__qtablewidgetitem12 = new QTableWidgetItem();
        tableWidget->setItem(0, 1, __qtablewidgetitem12);
        QTableWidgetItem *__qtablewidgetitem13 = new QTableWidgetItem();
        tableWidget->setItem(0, 2, __qtablewidgetitem13);
        QTableWidgetItem *__qtablewidgetitem14 = new QTableWidgetItem();
        tableWidget->setItem(0, 3, __qtablewidgetitem14);
        QTableWidgetItem *__qtablewidgetitem15 = new QTableWidgetItem();
        tableWidget->setItem(0, 4, __qtablewidgetitem15);
        QTableWidgetItem *__qtablewidgetitem16 = new QTableWidgetItem();
        tableWidget->setItem(0, 5, __qtablewidgetitem16);
        QTableWidgetItem *__qtablewidgetitem17 = new QTableWidgetItem();
        tableWidget->setItem(1, 0, __qtablewidgetitem17);
        QTableWidgetItem *__qtablewidgetitem18 = new QTableWidgetItem();
        tableWidget->setItem(1, 1, __qtablewidgetitem18);
        QTableWidgetItem *__qtablewidgetitem19 = new QTableWidgetItem();
        tableWidget->setItem(1, 2, __qtablewidgetitem19);
        QTableWidgetItem *__qtablewidgetitem20 = new QTableWidgetItem();
        tableWidget->setItem(1, 3, __qtablewidgetitem20);
        QTableWidgetItem *__qtablewidgetitem21 = new QTableWidgetItem();
        tableWidget->setItem(1, 4, __qtablewidgetitem21);
        QTableWidgetItem *__qtablewidgetitem22 = new QTableWidgetItem();
        tableWidget->setItem(1, 5, __qtablewidgetitem22);
        QTableWidgetItem *__qtablewidgetitem23 = new QTableWidgetItem();
        tableWidget->setItem(2, 0, __qtablewidgetitem23);
        QTableWidgetItem *__qtablewidgetitem24 = new QTableWidgetItem();
        tableWidget->setItem(2, 1, __qtablewidgetitem24);
        QTableWidgetItem *__qtablewidgetitem25 = new QTableWidgetItem();
        tableWidget->setItem(2, 2, __qtablewidgetitem25);
        QTableWidgetItem *__qtablewidgetitem26 = new QTableWidgetItem();
        tableWidget->setItem(2, 3, __qtablewidgetitem26);
        QTableWidgetItem *__qtablewidgetitem27 = new QTableWidgetItem();
        tableWidget->setItem(2, 4, __qtablewidgetitem27);
        QTableWidgetItem *__qtablewidgetitem28 = new QTableWidgetItem();
        tableWidget->setItem(2, 5, __qtablewidgetitem28);
        QTableWidgetItem *__qtablewidgetitem29 = new QTableWidgetItem();
        tableWidget->setItem(3, 0, __qtablewidgetitem29);
        QTableWidgetItem *__qtablewidgetitem30 = new QTableWidgetItem();
        tableWidget->setItem(3, 1, __qtablewidgetitem30);
        QTableWidgetItem *__qtablewidgetitem31 = new QTableWidgetItem();
        tableWidget->setItem(3, 2, __qtablewidgetitem31);
        QTableWidgetItem *__qtablewidgetitem32 = new QTableWidgetItem();
        tableWidget->setItem(3, 3, __qtablewidgetitem32);
        QTableWidgetItem *__qtablewidgetitem33 = new QTableWidgetItem();
        tableWidget->setItem(3, 4, __qtablewidgetitem33);
        QTableWidgetItem *__qtablewidgetitem34 = new QTableWidgetItem();
        tableWidget->setItem(3, 5, __qtablewidgetitem34);
        QTableWidgetItem *__qtablewidgetitem35 = new QTableWidgetItem();
        tableWidget->setItem(4, 0, __qtablewidgetitem35);
        QTableWidgetItem *__qtablewidgetitem36 = new QTableWidgetItem();
        tableWidget->setItem(4, 1, __qtablewidgetitem36);
        QTableWidgetItem *__qtablewidgetitem37 = new QTableWidgetItem();
        tableWidget->setItem(4, 2, __qtablewidgetitem37);
        QTableWidgetItem *__qtablewidgetitem38 = new QTableWidgetItem();
        tableWidget->setItem(4, 3, __qtablewidgetitem38);
        QTableWidgetItem *__qtablewidgetitem39 = new QTableWidgetItem();
        tableWidget->setItem(4, 4, __qtablewidgetitem39);
        QTableWidgetItem *__qtablewidgetitem40 = new QTableWidgetItem();
        tableWidget->setItem(4, 5, __qtablewidgetitem40);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setGeometry(QRect(20, 80, 771, 181));
        tableWidget->horizontalHeader()->setDefaultSectionSize(125);
        pushButton = new QPushButton(DialogMempleados);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(380, 300, 75, 23));

        retranslateUi(DialogMempleados);

        QMetaObject::connectSlotsByName(DialogMempleados);
    } // setupUi

    void retranslateUi(QDialog *DialogMempleados)
    {
        DialogMempleados->setWindowTitle(QCoreApplication::translate("DialogMempleados", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("DialogMempleados", "Mostrar empleados", nullptr));
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("DialogMempleados", "Legajo", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("DialogMempleados", "Nombre", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QCoreApplication::translate("DialogMempleados", "Apellido", nullptr));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QCoreApplication::translate("DialogMempleados", "Area", nullptr));
        QTableWidgetItem *___qtablewidgetitem4 = tableWidget->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QCoreApplication::translate("DialogMempleados", "Puesto", nullptr));
        QTableWidgetItem *___qtablewidgetitem5 = tableWidget->horizontalHeaderItem(5);
        ___qtablewidgetitem5->setText(QCoreApplication::translate("DialogMempleados", "Sueldo", nullptr));
        QTableWidgetItem *___qtablewidgetitem6 = tableWidget->verticalHeaderItem(0);
        ___qtablewidgetitem6->setText(QCoreApplication::translate("DialogMempleados", "1", nullptr));
        QTableWidgetItem *___qtablewidgetitem7 = tableWidget->verticalHeaderItem(1);
        ___qtablewidgetitem7->setText(QCoreApplication::translate("DialogMempleados", "2", nullptr));
        QTableWidgetItem *___qtablewidgetitem8 = tableWidget->verticalHeaderItem(2);
        ___qtablewidgetitem8->setText(QCoreApplication::translate("DialogMempleados", "3", nullptr));
        QTableWidgetItem *___qtablewidgetitem9 = tableWidget->verticalHeaderItem(3);
        ___qtablewidgetitem9->setText(QCoreApplication::translate("DialogMempleados", "4", nullptr));
        QTableWidgetItem *___qtablewidgetitem10 = tableWidget->verticalHeaderItem(4);
        ___qtablewidgetitem10->setText(QCoreApplication::translate("DialogMempleados", "5", nullptr));

        const bool __sortingEnabled = tableWidget->isSortingEnabled();
        tableWidget->setSortingEnabled(false);
        QTableWidgetItem *___qtablewidgetitem11 = tableWidget->item(0, 0);
        ___qtablewidgetitem11->setText(QCoreApplication::translate("DialogMempleados", "1", nullptr));
        QTableWidgetItem *___qtablewidgetitem12 = tableWidget->item(0, 1);
        ___qtablewidgetitem12->setText(QCoreApplication::translate("DialogMempleados", "Joel", nullptr));
        QTableWidgetItem *___qtablewidgetitem13 = tableWidget->item(0, 2);
        ___qtablewidgetitem13->setText(QCoreApplication::translate("DialogMempleados", "Traverso", nullptr));
        QTableWidgetItem *___qtablewidgetitem14 = tableWidget->item(0, 3);
        ___qtablewidgetitem14->setText(QCoreApplication::translate("DialogMempleados", "Administracion", nullptr));
        QTableWidgetItem *___qtablewidgetitem15 = tableWidget->item(0, 4);
        ___qtablewidgetitem15->setText(QCoreApplication::translate("DialogMempleados", "Gerente General", nullptr));
        QTableWidgetItem *___qtablewidgetitem16 = tableWidget->item(0, 5);
        ___qtablewidgetitem16->setText(QCoreApplication::translate("DialogMempleados", "150000", nullptr));
        QTableWidgetItem *___qtablewidgetitem17 = tableWidget->item(1, 0);
        ___qtablewidgetitem17->setText(QCoreApplication::translate("DialogMempleados", "2", nullptr));
        QTableWidgetItem *___qtablewidgetitem18 = tableWidget->item(1, 1);
        ___qtablewidgetitem18->setText(QCoreApplication::translate("DialogMempleados", "Mauricio", nullptr));
        QTableWidgetItem *___qtablewidgetitem19 = tableWidget->item(1, 2);
        ___qtablewidgetitem19->setText(QCoreApplication::translate("DialogMempleados", "Fernandez", nullptr));
        QTableWidgetItem *___qtablewidgetitem20 = tableWidget->item(1, 3);
        ___qtablewidgetitem20->setText(QCoreApplication::translate("DialogMempleados", "Administracion", nullptr));
        QTableWidgetItem *___qtablewidgetitem21 = tableWidget->item(1, 4);
        ___qtablewidgetitem21->setText(QCoreApplication::translate("DialogMempleados", "Secretario Gerencia", nullptr));
        QTableWidgetItem *___qtablewidgetitem22 = tableWidget->item(1, 5);
        ___qtablewidgetitem22->setText(QCoreApplication::translate("DialogMempleados", "60000", nullptr));
        QTableWidgetItem *___qtablewidgetitem23 = tableWidget->item(2, 0);
        ___qtablewidgetitem23->setText(QCoreApplication::translate("DialogMempleados", "9999", nullptr));
        QTableWidgetItem *___qtablewidgetitem24 = tableWidget->item(2, 1);
        ___qtablewidgetitem24->setText(QCoreApplication::translate("DialogMempleados", "Ramiro", nullptr));
        QTableWidgetItem *___qtablewidgetitem25 = tableWidget->item(2, 2);
        ___qtablewidgetitem25->setText(QCoreApplication::translate("DialogMempleados", "Deocares", nullptr));
        QTableWidgetItem *___qtablewidgetitem26 = tableWidget->item(2, 3);
        ___qtablewidgetitem26->setText(QCoreApplication::translate("DialogMempleados", "Limpieza", nullptr));
        QTableWidgetItem *___qtablewidgetitem27 = tableWidget->item(2, 4);
        ___qtablewidgetitem27->setText(QCoreApplication::translate("DialogMempleados", "Conchita", nullptr));
        QTableWidgetItem *___qtablewidgetitem28 = tableWidget->item(2, 5);
        ___qtablewidgetitem28->setText(QCoreApplication::translate("DialogMempleados", "0", nullptr));
        QTableWidgetItem *___qtablewidgetitem29 = tableWidget->item(3, 0);
        ___qtablewidgetitem29->setText(QCoreApplication::translate("DialogMempleados", "-3", nullptr));
        QTableWidgetItem *___qtablewidgetitem30 = tableWidget->item(3, 1);
        ___qtablewidgetitem30->setText(QCoreApplication::translate("DialogMempleados", "Tormenta", nullptr));
        QTableWidgetItem *___qtablewidgetitem31 = tableWidget->item(3, 2);
        ___qtablewidgetitem31->setText(QCoreApplication::translate("DialogMempleados", "De Fernandez", nullptr));
        QTableWidgetItem *___qtablewidgetitem32 = tableWidget->item(3, 3);
        ___qtablewidgetitem32->setText(QCoreApplication::translate("DialogMempleados", "Administracion", nullptr));
        QTableWidgetItem *___qtablewidgetitem33 = tableWidget->item(3, 4);
        ___qtablewidgetitem33->setText(QCoreApplication::translate("DialogMempleados", "Secretaria del Secretario", nullptr));
        QTableWidgetItem *___qtablewidgetitem34 = tableWidget->item(3, 5);
        ___qtablewidgetitem34->setText(QCoreApplication::translate("DialogMempleados", "100", nullptr));
        QTableWidgetItem *___qtablewidgetitem35 = tableWidget->item(4, 0);
        ___qtablewidgetitem35->setText(QCoreApplication::translate("DialogMempleados", "0", nullptr));
        QTableWidgetItem *___qtablewidgetitem36 = tableWidget->item(4, 1);
        ___qtablewidgetitem36->setText(QCoreApplication::translate("DialogMempleados", "Jonas", nullptr));
        QTableWidgetItem *___qtablewidgetitem37 = tableWidget->item(4, 2);
        ___qtablewidgetitem37->setText(QCoreApplication::translate("DialogMempleados", "ellacopulos", nullptr));
        QTableWidgetItem *___qtablewidgetitem38 = tableWidget->item(4, 3);
        ___qtablewidgetitem38->setText(QCoreApplication::translate("DialogMempleados", "Administracion", nullptr));
        QTableWidgetItem *___qtablewidgetitem39 = tableWidget->item(4, 4);
        ___qtablewidgetitem39->setText(QCoreApplication::translate("DialogMempleados", "Dios", nullptr));
        QTableWidgetItem *___qtablewidgetitem40 = tableWidget->item(4, 5);
        ___qtablewidgetitem40->setText(QCoreApplication::translate("DialogMempleados", "\342\210\236", nullptr));
        tableWidget->setSortingEnabled(__sortingEnabled);

        pushButton->setText(QCoreApplication::translate("DialogMempleados", "OK", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DialogMempleados: public Ui_DialogMempleados {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGMEMPLEADOS_H
