/********************************************************************************
** Form generated from reading UI file 'dialogmproducto.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGMPRODUCTO_H
#define UI_DIALOGMPRODUCTO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_DialogMproducto
{
public:
    QLabel *label_2;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label;
    QCheckBox *checkBox;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_10;
    QPushButton *pushButton;
    QLabel *label_11;
    QLineEdit *lineEdit;
    QPushButton *pushButton_2;
    QFrame *line;

    void setupUi(QDialog *DialogMproducto)
    {
        if (DialogMproducto->objectName().isEmpty())
            DialogMproducto->setObjectName(QString::fromUtf8("DialogMproducto"));
        DialogMproducto->resize(383, 326);
        QFont font;
        font.setFamily(QString::fromUtf8("Arial"));
        font.setPointSize(12);
        DialogMproducto->setFont(font);
        label_2 = new QLabel(DialogMproducto);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(22, 119, 61, 16));
        label_5 = new QLabel(DialogMproducto);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(22, 209, 47, 13));
        label_6 = new QLabel(DialogMproducto);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(22, 239, 61, 16));
        label = new QLabel(DialogMproducto);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(60, 10, 271, 31));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Arial"));
        font1.setPointSize(24);
        font1.setBold(true);
        font1.setWeight(75);
        label->setFont(font1);
        checkBox = new QCheckBox(DialogMproducto);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        checkBox->setGeometry(QRect(81, 239, 16, 20));
        checkBox->setChecked(true);
        label_3 = new QLabel(DialogMproducto);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(22, 149, 91, 16));
        label_4 = new QLabel(DialogMproducto);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(22, 179, 71, 16));
        label_7 = new QLabel(DialogMproducto);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(85, 118, 161, 16));
        label_8 = new QLabel(DialogMproducto);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(114, 149, 161, 16));
        label_9 = new QLabel(DialogMproducto);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(88, 180, 47, 13));
        label_10 = new QLabel(DialogMproducto);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(70, 210, 47, 13));
        pushButton = new QPushButton(DialogMproducto);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(140, 280, 75, 23));
        label_11 = new QLabel(DialogMproducto);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(22, 60, 21, 16));
        lineEdit = new QLineEdit(DialogMproducto);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(42, 58, 51, 20));
        pushButton_2 = new QPushButton(DialogMproducto);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(100, 56, 75, 23));
        line = new QFrame(DialogMproducto);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(20, 90, 341, 16));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        retranslateUi(DialogMproducto);

        QMetaObject::connectSlotsByName(DialogMproducto);
    } // setupUi

    void retranslateUi(QDialog *DialogMproducto)
    {
        DialogMproducto->setWindowTitle(QCoreApplication::translate("DialogMproducto", "Dialog", nullptr));
        label_2->setText(QCoreApplication::translate("DialogMproducto", "Nombre:", nullptr));
        label_5->setText(QCoreApplication::translate("DialogMproducto", "Stock:", nullptr));
        label_6->setText(QCoreApplication::translate("DialogMproducto", "Estado:", nullptr));
        label->setText(QCoreApplication::translate("DialogMproducto", "Buscar  Producto", nullptr));
        checkBox->setText(QString());
        label_3->setText(QCoreApplication::translate("DialogMproducto", "Descripcion:", nullptr));
        label_4->setText(QCoreApplication::translate("DialogMproducto", "Precio: $", nullptr));
        label_7->setText(QCoreApplication::translate("DialogMproducto", "Vino Trapiche 980cm3", nullptr));
        label_8->setText(QCoreApplication::translate("DialogMproducto", "Vino Malbec Mendoza", nullptr));
        label_9->setText(QCoreApplication::translate("DialogMproducto", "560", nullptr));
        label_10->setText(QCoreApplication::translate("DialogMproducto", "80", nullptr));
        pushButton->setText(QCoreApplication::translate("DialogMproducto", "OK", nullptr));
        label_11->setText(QCoreApplication::translate("DialogMproducto", "ID:", nullptr));
        pushButton_2->setText(QCoreApplication::translate("DialogMproducto", "Consulta", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DialogMproducto: public Ui_DialogMproducto {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGMPRODUCTO_H
