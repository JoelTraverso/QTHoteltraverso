/********************************************************************************
** Form generated from reading UI file 'mainwindowlogin.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOWLOGIN_H
#define UI_MAINWINDOWLOGIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindowlogin
{
public:
    QWidget *centralwidget;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *lineEdit_user;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QLineEdit *lineEdit_pass;
    QPushButton *pushButton_login;
    QLabel *label_3;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindowlogin)
    {
        if (MainWindowlogin->objectName().isEmpty())
            MainWindowlogin->setObjectName(QString::fromUtf8("MainWindowlogin"));
        MainWindowlogin->resize(458, 290);
        QFont font;
        font.setFamily(QString::fromUtf8("Arial"));
        font.setPointSize(12);
        MainWindowlogin->setFont(font);
        centralwidget = new QWidget(MainWindowlogin);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        groupBox = new QGroupBox(centralwidget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(90, 80, 263, 128));
        verticalLayout = new QVBoxLayout(groupBox);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(groupBox);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        lineEdit_user = new QLineEdit(groupBox);
        lineEdit_user->setObjectName(QString::fromUtf8("lineEdit_user"));

        horizontalLayout->addWidget(lineEdit_user);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_2->addWidget(label_2);

        lineEdit_pass = new QLineEdit(groupBox);
        lineEdit_pass->setObjectName(QString::fromUtf8("lineEdit_pass"));
        lineEdit_pass->setEchoMode(QLineEdit::Password);

        horizontalLayout_2->addWidget(lineEdit_pass);


        verticalLayout->addLayout(horizontalLayout_2);

        pushButton_login = new QPushButton(groupBox);
        pushButton_login->setObjectName(QString::fromUtf8("pushButton_login"));

        verticalLayout->addWidget(pushButton_login);

        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(80, 10, 291, 51));
        QFont font1;
        font1.setPointSize(24);
        font1.setBold(true);
        font1.setWeight(75);
        label_3->setFont(font1);
        MainWindowlogin->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindowlogin);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 458, 21));
        MainWindowlogin->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindowlogin);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindowlogin->setStatusBar(statusbar);

        retranslateUi(MainWindowlogin);

        QMetaObject::connectSlotsByName(MainWindowlogin);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindowlogin)
    {
        MainWindowlogin->setWindowTitle(QCoreApplication::translate("MainWindowlogin", "MainWindow", nullptr));
        groupBox->setTitle(QCoreApplication::translate("MainWindowlogin", "Login", nullptr));
        label->setText(QCoreApplication::translate("MainWindowlogin", "Usuario:", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindowlogin", "Contrase\303\261a:", nullptr));
        pushButton_login->setText(QCoreApplication::translate("MainWindowlogin", "Login", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindowlogin", "Ingreso Al Sistema", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindowlogin: public Ui_MainWindowlogin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOWLOGIN_H
