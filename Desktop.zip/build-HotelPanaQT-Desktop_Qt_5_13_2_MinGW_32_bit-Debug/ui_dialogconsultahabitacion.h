/********************************************************************************
** Form generated from reading UI file 'dialogconsultahabitacion.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGCONSULTAHABITACION_H
#define UI_DIALOGCONSULTAHABITACION_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_DialogConsultaHabitacion
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLineEdit *lineEdit_hab;
    QLabel *label_5;
    QLabel *label_tipo;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_10;
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QDialog *DialogConsultaHabitacion)
    {
        if (DialogConsultaHabitacion->objectName().isEmpty())
            DialogConsultaHabitacion->setObjectName(QString::fromUtf8("DialogConsultaHabitacion"));
        DialogConsultaHabitacion->resize(374, 264);
        QFont font;
        font.setFamily(QString::fromUtf8("Arial"));
        font.setPointSize(12);
        DialogConsultaHabitacion->setFont(font);
        label = new QLabel(DialogConsultaHabitacion);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(40, 10, 321, 41));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Arial"));
        font1.setPointSize(24);
        font1.setBold(true);
        font1.setWeight(75);
        label->setFont(font1);
        label_2 = new QLabel(DialogConsultaHabitacion);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(20, 60, 21, 16));
        label_3 = new QLabel(DialogConsultaHabitacion);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(41, 61, 47, 13));
        label_4 = new QLabel(DialogConsultaHabitacion);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(20, 90, 81, 16));
        lineEdit_hab = new QLineEdit(DialogConsultaHabitacion);
        lineEdit_hab->setObjectName(QString::fromUtf8("lineEdit_hab"));
        lineEdit_hab->setGeometry(QRect(100, 87, 113, 20));
        label_5 = new QLabel(DialogConsultaHabitacion);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(20, 120, 81, 16));
        label_tipo = new QLabel(DialogConsultaHabitacion);
        label_tipo->setObjectName(QString::fromUtf8("label_tipo"));
        label_tipo->setGeometry(QRect(70, 121, 131, 16));
        label_7 = new QLabel(DialogConsultaHabitacion);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(20, 150, 81, 16));
        label_8 = new QLabel(DialogConsultaHabitacion);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(80, 150, 81, 16));
        label_9 = new QLabel(DialogConsultaHabitacion);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(20, 180, 61, 16));
        label_10 = new QLabel(DialogConsultaHabitacion);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(80, 180, 81, 16));
        pushButton = new QPushButton(DialogConsultaHabitacion);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(180, 220, 75, 23));
        pushButton_2 = new QPushButton(DialogConsultaHabitacion);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(80, 220, 75, 23));

        retranslateUi(DialogConsultaHabitacion);

        QMetaObject::connectSlotsByName(DialogConsultaHabitacion);
    } // setupUi

    void retranslateUi(QDialog *DialogConsultaHabitacion)
    {
        DialogConsultaHabitacion->setWindowTitle(QCoreApplication::translate("DialogConsultaHabitacion", "Consulta Habitacion", nullptr));
        label->setText(QCoreApplication::translate("DialogConsultaHabitacion", "Consulta Habitaci\303\263n", nullptr));
        label_2->setText(QCoreApplication::translate("DialogConsultaHabitacion", "ID:", nullptr));
        label_3->setText(QCoreApplication::translate("DialogConsultaHabitacion", "125", nullptr));
        label_4->setText(QCoreApplication::translate("DialogConsultaHabitacion", "Habitaci\303\263n:", nullptr));
        label_5->setText(QCoreApplication::translate("DialogConsultaHabitacion", "Clase:", nullptr));
        label_tipo->setText(QString());
        label_7->setText(QCoreApplication::translate("DialogConsultaHabitacion", "Costo: $", nullptr));
        label_8->setText(QCoreApplication::translate("DialogConsultaHabitacion", "2500", nullptr));
        label_9->setText(QCoreApplication::translate("DialogConsultaHabitacion", "Estado:", nullptr));
        label_10->setText(QCoreApplication::translate("DialogConsultaHabitacion", "Ocupada", nullptr));
        pushButton->setText(QCoreApplication::translate("DialogConsultaHabitacion", "Salir", nullptr));
        pushButton_2->setText(QCoreApplication::translate("DialogConsultaHabitacion", "Consultar", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DialogConsultaHabitacion: public Ui_DialogConsultaHabitacion {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGCONSULTAHABITACION_H
