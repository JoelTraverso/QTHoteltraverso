#ifndef DIALOGCRESERVA_H
#define DIALOGCRESERVA_H

#include <QDialog>

namespace Ui {
class DialogCreserva;
}

class DialogCreserva : public QDialog
{
    Q_OBJECT

public:
    explicit DialogCreserva(QWidget *parent = nullptr);
    ~DialogCreserva();

private:
    Ui::DialogCreserva *ui;
};

#endif // DIALOGCRESERVA_H
