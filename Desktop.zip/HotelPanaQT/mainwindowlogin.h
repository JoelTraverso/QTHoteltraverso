#ifndef MAINWINDOWLOGIN_H
#define MAINWINDOWLOGIN_H

#include <QMainWindow>
#include "mainwindow.h"
namespace Ui {
class MainWindowlogin;
}

class MainWindowlogin : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindowlogin(QWidget *parent = nullptr);
    ~MainWindowlogin();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_login_clicked();

private:
    Ui::MainWindowlogin *ui;
    MainWindow *mainw;
};

#endif // MAINWINDOWLOGIN_H
