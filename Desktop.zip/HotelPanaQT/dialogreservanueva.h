#ifndef DIALOGRESERVANUEVA_H
#define DIALOGRESERVANUEVA_H

#include <QDialog>


namespace Ui {
class DialogReservaNueva;
}

class DialogReservaNueva : public QDialog
{
    Q_OBJECT

public:
    explicit DialogReservaNueva(QWidget *parent = nullptr);
    ~DialogReservaNueva();

private:
    Ui::DialogReservaNueva *ui;
};

#endif // DIALOGRESERVANUEVA_H
