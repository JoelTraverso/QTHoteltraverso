#include "dialogaproducto.h"
#include "ui_dialogaproducto.h"

DialogAproducto::DialogAproducto(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogAproducto)
{
    ui->setupUi(this);
}

DialogAproducto::~DialogAproducto()
{
    delete ui;
}
