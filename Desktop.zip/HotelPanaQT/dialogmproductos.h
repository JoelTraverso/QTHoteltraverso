#ifndef DIALOGMPRODUCTOS_H
#define DIALOGMPRODUCTOS_H

#include <QDialog>

namespace Ui {
class DialogMproductos;
}

class DialogMproductos : public QDialog
{
    Q_OBJECT

public:
    explicit DialogMproductos(QWidget *parent = nullptr);
    ~DialogMproductos();

private:
    Ui::DialogMproductos *ui;
};

#endif // DIALOGMPRODUCTOS_H
