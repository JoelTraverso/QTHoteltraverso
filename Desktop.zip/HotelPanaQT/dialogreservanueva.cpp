#include "dialogreservanueva.h"
#include "ui_dialogreservanueva.h"

DialogReservaNueva::DialogReservaNueva(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogReservaNueva)
{
    ui->setupUi(this);
}

DialogReservaNueva::~DialogReservaNueva()
{
    delete ui;
}

