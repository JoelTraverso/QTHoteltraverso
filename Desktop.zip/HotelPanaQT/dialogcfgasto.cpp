#include "dialogcfgasto.h"
#include "ui_dialogcfgasto.h"

DialogCFgasto::DialogCFgasto(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogCFgasto)
{
    ui->setupUi(this);
}

DialogCFgasto::~DialogCFgasto()
{
    delete ui;
}
