#ifndef DIALOGCEMPLEADO_H
#define DIALOGCEMPLEADO_H

#include <QDialog>

namespace Ui {
class DialogCempleado;
}

class DialogCempleado : public QDialog
{
    Q_OBJECT

public:
    explicit DialogCempleado(QWidget *parent = nullptr);
    ~DialogCempleado();

private:
    Ui::DialogCempleado *ui;
};

#endif // DIALOGCEMPLEADO_H
