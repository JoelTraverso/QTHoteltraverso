#ifndef DIALOGCPRODUCTO_H
#define DIALOGCPRODUCTO_H

#include <QDialog>

namespace Ui {
class DialogCproducto;
}

class DialogCproducto : public QDialog
{
    Q_OBJECT

public:
    explicit DialogCproducto(QWidget *parent = nullptr);
    ~DialogCproducto();

private:
    Ui::DialogCproducto *ui;
};

#endif // DIALOGCPRODUCTO_H
