#ifndef DIALOGCONSULTAHABITACION_H
#define DIALOGCONSULTAHABITACION_H

#include <QDialog>
#include "qstring.h"
#include "Habitaciones.h"
namespace Ui {
class DialogConsultaHabitacion;
}

class DialogConsultaHabitacion : public QDialog
{
    Q_OBJECT

public:
    explicit DialogConsultaHabitacion(QWidget *parent = nullptr);
    ~DialogConsultaHabitacion();

private slots:
    void on_pushButton_2_clicked();

private:
    Ui::DialogConsultaHabitacion *ui;
};

#endif // DIALOGCONSULTAHABITACION_H
