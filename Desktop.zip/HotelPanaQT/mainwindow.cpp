#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_actionNueva_Reserva_triggered()
{
    DialogReservaNueva *ventanareserva1= new DialogReservaNueva(this);
    ventanareserva1->setModal(true);
    ventanareserva1->show();

}

void MainWindow::on_actionCrear_Nueva_Habitaci_n_triggered()
{
    DialogNuevaHabitacion *ventanaNhabitacion= new DialogNuevaHabitacion(this);
    ventanaNhabitacion->setModal(true);
    ventanaNhabitacion->show();
}

void MainWindow::on_actionConsultar_Habitaci_nes_triggered()
{
    DialogConsultaHabitacion *ventanaChabitacion= new DialogConsultaHabitacion(this);
    ventanaChabitacion->setModal(true);
    ventanaChabitacion->show();
}



void MainWindow::on_actionCargar_Gasto_triggered()
{
    Dialogcargargasto *ventanaCgasto=new Dialogcargargasto(this);
    ventanaCgasto->setModal(true);
    ventanaCgasto->show();
}

void MainWindow::on_actionCancelar_Reserva_triggered()
{
    DialogCreserva *ventanaCreserva=new DialogCreserva(this);
    ventanaCreserva->setModal(true);
    ventanaCreserva->show();
}

void MainWindow::on_actionVer_Calendario_Reservas_triggered()
{
    DialogCalendarioR *ventanaCalendarioR=new DialogCalendarioR(this);
    ventanaCalendarioR->setModal(true);
    ventanaCalendarioR->show();
}

void MainWindow::on_actionModificar_Gasto_triggered()
{
    DialogMgasto *ventanaMgasto=new DialogMgasto(this);
    ventanaMgasto->setModal(true);
    ventanaMgasto->show();
}

void MainWindow::on_actionAnular_Gasto_triggered()
{
    DialogAgasto *ventanaAgasto=new DialogAgasto(this);
    ventanaAgasto->setModal(true);
    ventanaAgasto->show();
}

void MainWindow::on_actionConsultar_Gastos_triggered()
{
    Dialogcgasto *ventanaCogasto=new Dialogcgasto(this);
    ventanaCogasto->setModal(true);
    ventanaCogasto->show();
}

void MainWindow::on_actionConsultar_Gasto_Fecha_triggered()
{
    DialogCFgasto *ventanaCFgasto=new DialogCFgasto(this);
    ventanaCFgasto->setModal(true);
    ventanaCFgasto->show();
}

void MainWindow::on_actionA_adir_Productos_triggered()
{
    DialogCproducto *ventanaCproducto=new DialogCproducto(this);
    ventanaCproducto->setModal(true);
    ventanaCproducto->show();
}

void MainWindow::on_actionA_adir_Stock_triggered()
{
    DialogCstock *ventanaCstock=new DialogCstock(this);
    ventanaCstock->setModal(true);
    ventanaCstock->show();
}

void MainWindow::on_actionBuscar_Producto_triggered()
{
    DialogMproducto *ventanaBproducto=new DialogMproducto(this);
    ventanaBproducto->setModal(true);
    ventanaBproducto->show();
}

void MainWindow::on_actionMostrar_Productos_triggered()
{
    DialogMproductos *ventanaMproducto=new DialogMproductos(this);
    ventanaMproducto->setModal(true);
    ventanaMproducto->show();
}

void MainWindow::on_actionDar_Alta_Producto_triggered()
{
    DialogAproducto *ventanaAproducto=new DialogAproducto(this);
    ventanaAproducto->setModal(true);
    ventanaAproducto->show();
}

void MainWindow::on_actionCargar_Empleado_triggered()
{
    DialogCempleado *ventanaCempleado=new DialogCempleado(this);
    ventanaCempleado->setModal(true);
    ventanaCempleado->show();
}

void MainWindow::on_actionMostrar_Empleados_triggered()
{
    DialogMempleados *ventanaMempleados=new DialogMempleados(this);
    ventanaMempleados->setModal(true);
    ventanaMempleados->show();
}

void MainWindow::on_actionModificar_Empleado_triggered()
{
    DialogMOempleados *ventanaMOempleado=new DialogMOempleados(this);
    ventanaMOempleado->setModal(true);
    ventanaMOempleado->show();
}


