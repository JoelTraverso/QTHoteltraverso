#ifndef DIALOGAPRODUCTO_H
#define DIALOGAPRODUCTO_H

#include <QDialog>

namespace Ui {
class DialogAproducto;
}

class DialogAproducto : public QDialog
{
    Q_OBJECT

public:
    explicit DialogAproducto(QWidget *parent = nullptr);
    ~DialogAproducto();

private:
    Ui::DialogAproducto *ui;
};

#endif // DIALOGAPRODUCTO_H
