#include "dialogmproductos.h"
#include "ui_dialogmproductos.h"

DialogMproductos::DialogMproductos(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogMproductos)
{
    ui->setupUi(this);
}

DialogMproductos::~DialogMproductos()
{
    delete ui;
}
