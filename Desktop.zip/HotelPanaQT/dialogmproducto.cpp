#include "dialogmproducto.h"
#include "ui_dialogmproducto.h"

DialogMproducto::DialogMproducto(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogMproducto)
{
    ui->setupUi(this);
}

DialogMproducto::~DialogMproducto()
{
    delete ui;
}
