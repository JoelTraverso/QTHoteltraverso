#ifndef DIALOGMGASTO_H
#define DIALOGMGASTO_H

#include <QDialog>

namespace Ui {
class DialogMgasto;
}

class DialogMgasto : public QDialog
{
    Q_OBJECT

public:
    explicit DialogMgasto(QWidget *parent = nullptr);
    ~DialogMgasto();

private:
    Ui::DialogMgasto *ui;
};

#endif // DIALOGMGASTO_H
