#include "dialogcreserva.h"
#include "ui_dialogcreserva.h"

DialogCreserva::DialogCreserva(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogCreserva)
{
    ui->setupUi(this);
}

DialogCreserva::~DialogCreserva()
{
    delete ui;
}
