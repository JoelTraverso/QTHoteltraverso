#include "dialogagasto.h"
#include "ui_dialogagasto.h"

DialogAgasto::DialogAgasto(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogAgasto)
{
    ui->setupUi(this);
}

DialogAgasto::~DialogAgasto()
{
    delete ui;
}
