#ifndef DIALOGMPRODUCTO_H
#define DIALOGMPRODUCTO_H

#include <QDialog>

namespace Ui {
class DialogMproducto;
}

class DialogMproducto : public QDialog
{
    Q_OBJECT

public:
    explicit DialogMproducto(QWidget *parent = nullptr);
    ~DialogMproducto();

private:
    Ui::DialogMproducto *ui;
};

#endif // DIALOGMPRODUCTO_H
