#ifndef DIALOGCGASTO_H
#define DIALOGCGASTO_H

#include <QDialog>

namespace Ui {
class Dialogcgasto;
}

class Dialogcgasto : public QDialog
{
    Q_OBJECT

public:
    explicit Dialogcgasto(QWidget *parent = nullptr);
    ~Dialogcgasto();

private:
    Ui::Dialogcgasto *ui;
};

#endif // DIALOGCGASTO_H
