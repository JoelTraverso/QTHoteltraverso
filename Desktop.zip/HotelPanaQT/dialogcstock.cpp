#include "dialogcstock.h"
#include "ui_dialogcstock.h"

DialogCstock::DialogCstock(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogCstock)
{
    ui->setupUi(this);
}

DialogCstock::~DialogCstock()
{
    delete ui;
}
