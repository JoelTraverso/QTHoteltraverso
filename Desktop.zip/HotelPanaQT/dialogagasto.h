#ifndef DIALOGAGASTO_H
#define DIALOGAGASTO_H

#include <QDialog>

namespace Ui {
class DialogAgasto;
}

class DialogAgasto : public QDialog
{
    Q_OBJECT

public:
    explicit DialogAgasto(QWidget *parent = nullptr);
    ~DialogAgasto();

private:
    Ui::DialogAgasto *ui;
};

#endif // DIALOGAGASTO_H
