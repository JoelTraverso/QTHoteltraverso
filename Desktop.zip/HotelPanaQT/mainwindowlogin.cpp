#include "mainwindowlogin.h"
#include "ui_mainwindowlogin.h"
#include "qmessagebox.h"

MainWindowlogin::MainWindowlogin(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindowlogin)
{
    ui->setupUi(this);
}

MainWindowlogin::~MainWindowlogin()
{
    delete ui;
}

void MainWindowlogin::on_pushButton_login_clicked()
{
    QString username = ui->lineEdit_user->text();
    QString password = ui->lineEdit_pass->text();

    if(username == "admin" && password == "admin1")
    {
        QMessageBox::information(this,"OK","Bienvenido al sistema");
        hide();
        mainw = new MainWindow(this);
        mainw->show();

    }
    else {
        QMessageBox::warning(this,"EROR","Usuario o Contraseña Incorrecta");
    }
}
