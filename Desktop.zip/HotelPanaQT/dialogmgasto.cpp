#include "dialogmgasto.h"
#include "ui_dialogmgasto.h"

DialogMgasto::DialogMgasto(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogMgasto)
{
    ui->setupUi(this);
}

DialogMgasto::~DialogMgasto()
{
    delete ui;
}
