#include "dialogcempleado.h"
#include "ui_dialogcempleado.h"

DialogCempleado::DialogCempleado(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogCempleado)
{
    ui->setupUi(this);
}

DialogCempleado::~DialogCempleado()
{
    delete ui;
}
