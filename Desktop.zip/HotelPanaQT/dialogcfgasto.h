#ifndef DIALOGCFGASTO_H
#define DIALOGCFGASTO_H

#include <QDialog>

namespace Ui {
class DialogCFgasto;
}

class DialogCFgasto : public QDialog
{
    Q_OBJECT

public:
    explicit DialogCFgasto(QWidget *parent = nullptr);
    ~DialogCFgasto();

private:
    Ui::DialogCFgasto *ui;
};

#endif // DIALOGCFGASTO_H
