#ifndef DIALOGCSTOCK_H
#define DIALOGCSTOCK_H

#include <QDialog>

namespace Ui {
class DialogCstock;
}

class DialogCstock : public QDialog
{
    Q_OBJECT

public:
    explicit DialogCstock(QWidget *parent = nullptr);
    ~DialogCstock();

private:
    Ui::DialogCstock *ui;
};

#endif // DIALOGCSTOCK_H
