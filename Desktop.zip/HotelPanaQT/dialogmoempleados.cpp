#include "dialogmoempleados.h"
#include "ui_dialogmoempleados.h"

DialogMOempleados::DialogMOempleados(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogMOempleados)
{
    ui->setupUi(this);
}

DialogMOempleados::~DialogMOempleados()
{
    delete ui;
}
