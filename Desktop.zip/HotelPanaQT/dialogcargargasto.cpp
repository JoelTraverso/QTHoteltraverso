#include "dialogcargargasto.h"
#include "ui_dialogcargargasto.h"

Dialogcargargasto::Dialogcargargasto(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialogcargargasto)
{
    ui->setupUi(this);
}

Dialogcargargasto::~Dialogcargargasto()
{
    delete ui;
}
