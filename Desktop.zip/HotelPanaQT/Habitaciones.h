#ifndef HABITACIONES_H
#define HABITACIONES_H

#include "qstring.h"
#include "stdio.h"
#include "cstdlib"

class Habitaciones
{
private:
    QString numero,tipo;
public:
    void cargar(QString num,QString tip)
    {
        FILE  *p;
        p=fopen("pruba2.dat","ab");
        numero=num;
        tipo=tip;
        fwrite(this,sizeof(*this),1,p);
        fclose(p);
    }
    QString get_nom();
    QString get_tipo(QString hab)
    {
        FILE  *p;
        QString aux;
        p=fopen("prueba2.dat","rb");
        while(fread(this,sizeof(*this),1,p)==1)
        {
          if(numero==hab)
          {
              aux=tipo;
          }
        }
        fclose(p);
        return aux;
    }

};

//void Habitaciones::cargar(QString num,QString tip)


/*QString Habitaciones::get_nom()
{
    FILE static *p;
    QString aux;
    p=fopen("prueba.dat","rb");
    fseek(p,0,0);
    fread(this,sizeof(*this),1,p);
    aux=numero;
    fclose(p);
    return aux;
}*/

//QString Habitaciones::get_tipo(QString hab)

#endif // HABITACIONES_H
