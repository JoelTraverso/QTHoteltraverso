#include "dialogmempleados.h"
#include "ui_dialogmempleados.h"

DialogMempleados::DialogMempleados(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogMempleados)
{
    ui->setupUi(this);
}

DialogMempleados::~DialogMempleados()
{
    delete ui;
}
