#ifndef DIALOGNUEVAHABITACION_H
#define DIALOGNUEVAHABITACION_H

#include <QDialog>
#include "cstdlib"
#include "stdio.h"
#include "qfile.h"
#include "qstring.h"
#include "string.h"
#include "qmessagebox.h"
#include "qtextstream.h"
#include "Habitaciones.h"
namespace Ui {
class DialogNuevaHabitacion;
}

class DialogNuevaHabitacion : public QDialog
{
    Q_OBJECT

public:
    explicit DialogNuevaHabitacion(QWidget *parent = nullptr);
    ~DialogNuevaHabitacion();

private slots:
    void on_buttonBox_accepted();

    void on_pushButton_guardar_clicked();

private:
    Ui::DialogNuevaHabitacion *ui;
};

#endif // DIALOGNUEVAHABITACION_H
