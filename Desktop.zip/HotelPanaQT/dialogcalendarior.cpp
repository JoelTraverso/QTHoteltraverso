#include "dialogcalendarior.h"
#include "ui_dialogcalendarior.h"

DialogCalendarioR::DialogCalendarioR(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogCalendarioR)
{
    ui->setupUi(this);
}

DialogCalendarioR::~DialogCalendarioR()
{
    delete ui;
}
