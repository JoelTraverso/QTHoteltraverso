#ifndef DIALOGMOEMPLEADOS_H
#define DIALOGMOEMPLEADOS_H

#include <QDialog>

namespace Ui {
class DialogMOempleados;
}

class DialogMOempleados : public QDialog
{
    Q_OBJECT

public:
    explicit DialogMOempleados(QWidget *parent = nullptr);
    ~DialogMOempleados();

private:
    Ui::DialogMOempleados *ui;
};

#endif // DIALOGMOEMPLEADOS_H
