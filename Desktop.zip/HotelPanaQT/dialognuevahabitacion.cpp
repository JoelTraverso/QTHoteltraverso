#include "dialognuevahabitacion.h"
#include "ui_dialognuevahabitacion.h"
DialogNuevaHabitacion::DialogNuevaHabitacion(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogNuevaHabitacion)
{
    ui->setupUi(this);
}

DialogNuevaHabitacion::~DialogNuevaHabitacion()
{
    delete ui;
}


void DialogNuevaHabitacion::on_pushButton_guardar_clicked()
{
   /*QFile habitacion;
   habitacion.setFileName("habitacion.txt");
   if (!habitacion.open(QIODevice::WriteOnly| QIODevice::Text))
   {
       QMessageBox::warning(this,"Error","El archivo no pudo ser abierto");
   }
   QTextStream out(&habitacion);
   QString texto=ui->lineEdit_nhabitacion->text();
   out << texto;
   habitacion.flush();
   habitacion.close();*/
   QString textnum=ui->lineEdit_nhabitacion->text();
   QString texttipo=ui->comboBox_thabitacion->currentText();
   Habitaciones a;
   a.cargar(textnum,texttipo);

}

void DialogNuevaHabitacion::on_buttonBox_accepted()
{

}
