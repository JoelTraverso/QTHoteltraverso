#ifndef DIALOGMEMPLEADOS_H
#define DIALOGMEMPLEADOS_H

#include <QDialog>

namespace Ui {
class DialogMempleados;
}

class DialogMempleados : public QDialog
{
    Q_OBJECT

public:
    explicit DialogMempleados(QWidget *parent = nullptr);
    ~DialogMempleados();

private:
    Ui::DialogMempleados *ui;
};

#endif // DIALOGMEMPLEADOS_H
