#include "dialogconsultahabitacion.h"
#include "ui_dialogconsultahabitacion.h"

DialogConsultaHabitacion::DialogConsultaHabitacion(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogConsultaHabitacion)
{
    ui->setupUi(this);
}

DialogConsultaHabitacion::~DialogConsultaHabitacion()
{
    delete ui;
}

void DialogConsultaHabitacion::on_pushButton_2_clicked()
{
    QString num=ui->lineEdit_hab->text();
    Habitaciones a;
    ui->label_tipo->setText(a.get_tipo(num));
}
