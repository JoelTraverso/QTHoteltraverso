#ifndef DIALOGCALENDARIOR_H
#define DIALOGCALENDARIOR_H

#include <QDialog>

namespace Ui {
class DialogCalendarioR;
}

class DialogCalendarioR : public QDialog
{
    Q_OBJECT

public:
    explicit DialogCalendarioR(QWidget *parent = nullptr);
    ~DialogCalendarioR();

private:
    Ui::DialogCalendarioR *ui;
};

#endif // DIALOGCALENDARIOR_H
