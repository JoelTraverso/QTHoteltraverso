#ifndef DIALOGCARGARGASTO_H
#define DIALOGCARGARGASTO_H

#include <QDialog>

namespace Ui {
class Dialogcargargasto;
}

class Dialogcargargasto : public QDialog
{
    Q_OBJECT

public:
    explicit Dialogcargargasto(QWidget *parent = nullptr);
    ~Dialogcargargasto();

private:
    Ui::Dialogcargargasto *ui;
};

#endif // DIALOGCARGARGASTO_H
