#include "dialogcgasto.h"
#include "ui_dialogcgasto.h"

Dialogcgasto::Dialogcgasto(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialogcgasto)
{
    ui->setupUi(this);
}

Dialogcgasto::~Dialogcgasto()
{
    delete ui;
}
