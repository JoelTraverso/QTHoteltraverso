#include "dialogcproducto.h"
#include "ui_dialogcproducto.h"

DialogCproducto::DialogCproducto(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogCproducto)
{
    ui->setupUi(this);
}

DialogCproducto::~DialogCproducto()
{
    delete ui;
}
