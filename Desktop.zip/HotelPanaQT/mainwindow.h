#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <dialogreservanueva.h>
#include <dialognuevahabitacion.h>
#include <dialogconsultahabitacion.h>
#include <dialogcargargasto.h>
#include <dialogcreserva.h>
#include <dialogcalendarior.h>
#include <dialogmgasto.h>
#include <dialogagasto.h>
#include <dialogcgasto.h>
#include <dialogcfgasto.h>
#include <dialogcproducto.h>
#include <dialogcstock.h>
#include <dialogmproducto.h>
#include <dialogmproductos.h>
#include <dialogaproducto.h>
#include <dialogcempleado.h>
#include <dialogmempleados.h>
#include <dialogmoempleados.h>





QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_actionNueva_Reserva_triggered();

    void on_actionCrear_Nueva_Habitaci_n_triggered();

    void on_actionConsultar_Habitaci_nes_triggered();

    void on_actionCargar_Gasto_triggered();

    void on_actionCancelar_Reserva_triggered();

    void on_actionVer_Calendario_Reservas_triggered();

    void on_actionModificar_Gasto_triggered();

    void on_actionAnular_Gasto_triggered();

    void on_actionConsultar_Gastos_triggered();

    void on_actionConsultar_Gasto_Fecha_triggered();

    void on_actionA_adir_Productos_triggered();

    void on_actionA_adir_Stock_triggered();

    void on_actionBuscar_Producto_triggered();

    void on_actionMostrar_Productos_triggered();

    void on_actionDar_Alta_Producto_triggered();

    void on_actionCargar_Empleado_triggered();

    void on_actionMostrar_Empleados_triggered();

    void on_actionModificar_Empleado_triggered();

    void on_pushButton_login_clicked();

    void on_pushButton_clicked();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
